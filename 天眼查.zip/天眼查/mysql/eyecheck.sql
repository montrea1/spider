/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : eyecheck

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2018-12-30 13:25:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_abnormal
-- ----------------------------
DROP TABLE IF EXISTS `t_abnormal`;
CREATE TABLE `t_abnormal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `列入日期` varchar(45) DEFAULT NULL,
  `列入原因` varchar(300) DEFAULT NULL,
  `决定机关` varchar(45) DEFAULT NULL,
  `移除日期` varchar(45) DEFAULT NULL,
  `移除原因` varchar(300) DEFAULT NULL,
  `移除机关` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='经营异常';

-- ----------------------------
-- Table structure for t_announcementcourt
-- ----------------------------
DROP TABLE IF EXISTS `t_announcementcourt`;
CREATE TABLE `t_announcementcourt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `开庭日期` varchar(45) DEFAULT NULL,
  `案由` varchar(45) DEFAULT NULL,
  `原告` varchar(1000) DEFAULT NULL,
  `被告` varchar(1000) DEFAULT NULL,
  `操作` varchar(2000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=632 DEFAULT CHARSET=utf8 COMMENT='公司基本信息';

-- ----------------------------
-- Table structure for t_annualcheck
-- ----------------------------
DROP TABLE IF EXISTS `t_annualcheck`;
CREATE TABLE `t_annualcheck` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(255) NOT NULL,
  `年度` varchar(255) DEFAULT NULL,
  `年检结果` varchar(255) DEFAULT NULL,
  `纳税人识别号` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_baseinfo
-- ----------------------------
DROP TABLE IF EXISTS `t_baseinfo`;
CREATE TABLE `t_baseinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `电话` varchar(45) DEFAULT NULL,
  `邮箱` varchar(45) DEFAULT NULL,
  `网址` varchar(45) DEFAULT NULL,
  `地址` varchar(45) DEFAULT NULL,
  `简介` varchar(1000) DEFAULT NULL,
  `公司状态` varchar(45) DEFAULT NULL,
  `注册时间` varchar(45) DEFAULT NULL,
  `注册资本` varchar(45) DEFAULT NULL,
  `法定代表人` varchar(45) DEFAULT NULL,
  `工商注册号` varchar(45) DEFAULT NULL,
  `统一社会信用代码` varchar(45) DEFAULT NULL,
  `纳税人识别号` varchar(45) DEFAULT NULL,
  `营业期限` varchar(45) DEFAULT NULL,
  `纳税人资质` varchar(45) DEFAULT NULL,
  `实缴资本` varchar(45) DEFAULT NULL,
  `参保人数` varchar(45) DEFAULT NULL,
  `注册地址` varchar(45) DEFAULT NULL,
  `经营范围` varchar(500) DEFAULT NULL,
  `股权结构图` varchar(200) DEFAULT NULL,
  `组织机构代码` varchar(45) DEFAULT NULL,
  `公司类型` varchar(45) DEFAULT NULL,
  `行业` varchar(45) DEFAULT NULL,
  `核准日期` varchar(45) DEFAULT NULL,
  `人员规模` varchar(45) DEFAULT NULL,
  `登记机关` varchar(45) DEFAULT NULL,
  `英文名称` varchar(200) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_bid
-- ----------------------------
DROP TABLE IF EXISTS `t_bid`;
CREATE TABLE `t_bid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `发布时间` varchar(45) DEFAULT NULL,
  `标题` varchar(1000) DEFAULT NULL,
  `采购人` varchar(100) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='招投标';

-- ----------------------------
-- Table structure for t_bond
-- ----------------------------
DROP TABLE IF EXISTS `t_bond`;
CREATE TABLE `t_bond` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `发行日期` varchar(45) NOT NULL,
  `债券名称` varchar(45) DEFAULT NULL,
  `债券代码` varchar(45) DEFAULT NULL,
  `债券类型` varchar(100) DEFAULT NULL,
  `最新评级` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='债务信息';

-- ----------------------------
-- Table structure for t_bonus
-- ----------------------------
DROP TABLE IF EXISTS `t_bonus`;
CREATE TABLE `t_bonus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `董事会日期` varchar(255) DEFAULT NULL,
  `股东大会日期` varchar(255) DEFAULT NULL,
  `实施日期` varchar(255) DEFAULT NULL,
  `分红方案说明` varchar(255) DEFAULT NULL,
  `A股股权登记日` varchar(255) DEFAULT NULL,
  `A股股权除息日` varchar(255) DEFAULT NULL,
  `A股派息日` varchar(255) DEFAULT NULL,
  `方案进度` varchar(255) DEFAULT NULL,
  `股利支付率` varchar(255) DEFAULT NULL,
  `分红率` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_branch
-- ----------------------------
DROP TABLE IF EXISTS `t_branch`;
CREATE TABLE `t_branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `企业名称` varchar(45) DEFAULT NULL,
  `负责人` varchar(45) DEFAULT NULL,
  `注册时间` varchar(45) DEFAULT NULL,
  `状态` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='分支机构';

-- ----------------------------
-- Table structure for t_certificateitem
-- ----------------------------
DROP TABLE IF EXISTS `t_certificateitem`;
CREATE TABLE `t_certificateitem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(50) NOT NULL,
  `证书类型` varchar(200) DEFAULT NULL,
  `证书编号` varchar(50) DEFAULT NULL,
  `发证日期` varchar(45) DEFAULT NULL,
  `截止日期` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='资质证书';

-- ----------------------------
-- Table structure for t_change
-- ----------------------------
DROP TABLE IF EXISTS `t_change`;
CREATE TABLE `t_change` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `变更时间` varchar(45) DEFAULT NULL,
  `变更项目` varchar(45) DEFAULT NULL,
  `变更前` varchar(1000) DEFAULT NULL,
  `变更后` varchar(2000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='变更记录';

-- ----------------------------
-- Table structure for t_check
-- ----------------------------
DROP TABLE IF EXISTS `t_check`;
CREATE TABLE `t_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `日期` varchar(45) DEFAULT NULL,
  `类型` varchar(45) DEFAULT NULL,
  `结果` varchar(45) DEFAULT NULL,
  `检查实施机关` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='抽查检查';

-- ----------------------------
-- Table structure for t_clearingcount
-- ----------------------------
DROP TABLE IF EXISTS `t_clearingcount`;
CREATE TABLE `t_clearingcount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` bigint(20) NOT NULL,
  `清算组负责人` varchar(255) DEFAULT NULL,
  `清算组成员` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_court
-- ----------------------------
DROP TABLE IF EXISTS `t_court`;
CREATE TABLE `t_court` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `公告时间` varchar(45) DEFAULT NULL,
  `上诉方` varchar(1000) DEFAULT NULL,
  `被诉方` varchar(1000) DEFAULT NULL,
  `公告类型` varchar(100) DEFAULT NULL,
  `法院` varchar(100) DEFAULT NULL,
  `操作` varchar(200) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='开庭公告';

-- ----------------------------
-- Table structure for t_director
-- ----------------------------
DROP TABLE IF EXISTS `t_director`;
CREATE TABLE `t_director` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) DEFAULT NULL,
  `公司id` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) DEFAULT NULL,
  `姓名` varchar(255) DEFAULT NULL,
  `理事会职务` varchar(255) DEFAULT NULL,
  `性别` varchar(255) DEFAULT NULL,
  `年度会议次数` varchar(255) DEFAULT NULL,
  `工作单位及职务` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_dishonest
-- ----------------------------
DROP TABLE IF EXISTS `t_dishonest`;
CREATE TABLE `t_dishonest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `立案日期` varchar(45) DEFAULT NULL,
  `案号` varchar(45) DEFAULT NULL,
  `执行法院` varchar(45) DEFAULT NULL,
  `履行状态` varchar(45) DEFAULT NULL,
  `执行依据文号` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='失信人信息';

-- ----------------------------
-- Table structure for t_equity
-- ----------------------------
DROP TABLE IF EXISTS `t_equity`;
CREATE TABLE `t_equity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `公告时间` varchar(45) DEFAULT NULL,
  `登记编号` varchar(45) DEFAULT NULL,
  `出质人` varchar(45) DEFAULT NULL,
  `质权人` varchar(45) DEFAULT NULL,
  `状态` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='股权出质';

-- ----------------------------
-- Table structure for t_equitychange
-- ----------------------------
DROP TABLE IF EXISTS `t_equitychange`;
CREATE TABLE `t_equitychange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(255) NOT NULL,
  `时间` varchar(255) DEFAULT NULL,
  `变动原因` varchar(255) DEFAULT NULL,
  `变动后A股总股本` varchar(255) DEFAULT NULL,
  `变动后流通A股` varchar(255) DEFAULT NULL,
  `变动后限售A股` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_execution
-- ----------------------------
DROP TABLE IF EXISTS `t_execution`;
CREATE TABLE `t_execution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `立案日期` varchar(45) DEFAULT NULL,
  `执行标的` varchar(100) DEFAULT NULL,
  `案号` varchar(45) DEFAULT NULL,
  `执行法院` varchar(100) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='被执行人';

-- ----------------------------
-- Table structure for t_finance
-- ----------------------------
DROP TABLE IF EXISTS `t_finance`;
CREATE TABLE `t_finance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(255) NOT NULL,
  `净资产` varchar(255) DEFAULT NULL,
  `年度总收入` varchar(255) DEFAULT NULL,
  `捐赠收入` varchar(255) DEFAULT NULL,
  `投资收入` varchar(255) DEFAULT NULL,
  `服务收入` varchar(255) DEFAULT NULL,
  `政府补助收入` varchar(255) DEFAULT NULL,
  `其他收入` varchar(255) DEFAULT NULL,
  `用于公益事业的支出` varchar(255) DEFAULT NULL,
  `工作人员工资福利支出` varchar(255) DEFAULT NULL,
  `行政办公支出` varchar(255) DEFAULT NULL,
  `其他支出` varchar(255) DEFAULT NULL,
  `年度总支出` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_financing
-- ----------------------------
DROP TABLE IF EXISTS `t_financing`;
CREATE TABLE `t_financing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `时间` varchar(45) DEFAULT NULL,
  `轮次` varchar(45) DEFAULT NULL,
  `估值` varchar(45) DEFAULT NULL,
  `金额` varchar(45) DEFAULT NULL,
  `比例` varchar(45) DEFAULT NULL,
  `投资方` varchar(100) DEFAULT NULL,
  `新闻来源` varchar(200) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8 COMMENT='融资历史';

-- ----------------------------
-- Table structure for t_firmproduct
-- ----------------------------
DROP TABLE IF EXISTS `t_firmproduct`;
CREATE TABLE `t_firmproduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `服务名称` varchar(100) DEFAULT NULL,
  `服务功能` varchar(200) DEFAULT NULL,
  `服务类别` varchar(100) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='业务产品';

-- ----------------------------
-- Table structure for t_holder
-- ----------------------------
DROP TABLE IF EXISTS `t_holder`;
CREATE TABLE `t_holder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `股东` varchar(45) DEFAULT NULL,
  `出资比例` varchar(45) DEFAULT NULL,
  `认缴出资` varchar(45) DEFAULT NULL,
  `出资时间` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='股东';

-- ----------------------------
-- Table structure for t_icp
-- ----------------------------
DROP TABLE IF EXISTS `t_icp`;
CREATE TABLE `t_icp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `审核时间` varchar(45) DEFAULT NULL,
  `网站名称` varchar(100) DEFAULT NULL,
  `网站首页` varchar(45) DEFAULT NULL,
  `域名` varchar(300) DEFAULT NULL,
  `备案号` varchar(100) DEFAULT NULL,
  `状态` varchar(45) DEFAULT NULL,
  `单位性质` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='网站备案';

-- ----------------------------
-- Table structure for t_illegal
-- ----------------------------
DROP TABLE IF EXISTS `t_illegal`;
CREATE TABLE `t_illegal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `列入日期` varchar(45) DEFAULT NULL,
  `列入原因` varchar(200) DEFAULT NULL,
  `列入决定机关` varchar(45) DEFAULT NULL,
  `移出原因` varchar(200) DEFAULT NULL,
  `移出决定机关` varchar(45) DEFAULT NULL,
  `移出日期` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='严重违法';

-- ----------------------------
-- Table structure for t_importandexport
-- ----------------------------
DROP TABLE IF EXISTS `t_importandexport`;
CREATE TABLE `t_importandexport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `注册海关` varchar(45) DEFAULT NULL,
  `海关编码` varchar(45) DEFAULT NULL,
  `经营类别` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='进出口信息';

-- ----------------------------
-- Table structure for t_introduction
-- ----------------------------
DROP TABLE IF EXISTS `t_introduction`;
CREATE TABLE `t_introduction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(255) NOT NULL,
  `英文名称` varchar(255) DEFAULT NULL,
  `曾用名` varchar(255) DEFAULT NULL,
  `所属行业` varchar(255) DEFAULT NULL,
  `主营业务` varchar(255) DEFAULT NULL,
  `董事长` varchar(255) DEFAULT NULL,
  `董秘` varchar(255) DEFAULT NULL,
  `法人代表` varchar(255) DEFAULT NULL,
  `注册资本` varchar(255) DEFAULT NULL,
  `员工人数` varchar(255) DEFAULT NULL,
  `总经理` varchar(255) NOT NULL,
  `控股股东` varchar(255) DEFAULT NULL,
  `实际控制人` varchar(255) DEFAULT NULL,
  `最终控制人` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_invest
-- ----------------------------
DROP TABLE IF EXISTS `t_invest`;
CREATE TABLE `t_invest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司id` varchar(45) NOT NULL,
  `公司名称` varchar(45) NOT NULL,
  `被投资公司名称` varchar(45) DEFAULT NULL,
  `被投资法定代表人` varchar(45) DEFAULT NULL,
  `注册资本` varchar(45) DEFAULT NULL,
  `投资占比` varchar(45) DEFAULT NULL,
  `注册时间` varchar(45) DEFAULT NULL,
  `状态` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='对外投资';

-- ----------------------------
-- Table structure for t_investevent
-- ----------------------------
DROP TABLE IF EXISTS `t_investevent`;
CREATE TABLE `t_investevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `时间` varchar(45) DEFAULT NULL,
  `轮次` varchar(45) DEFAULT NULL,
  `金额` varchar(45) DEFAULT NULL,
  `投资方` varchar(45) DEFAULT NULL,
  `产品` varchar(45) DEFAULT NULL,
  `地区` varchar(45) DEFAULT NULL,
  `业务` varchar(45) DEFAULT NULL,
  `行业` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=338 DEFAULT CHARSET=utf8 COMMENT='投资事件';

-- ----------------------------
-- Table structure for t_jingpin
-- ----------------------------
DROP TABLE IF EXISTS `t_jingpin`;
CREATE TABLE `t_jingpin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `产品` varchar(100) DEFAULT NULL,
  `地区` varchar(100) DEFAULT NULL,
  `当前轮次` varchar(45) DEFAULT NULL,
  `行业` varchar(100) DEFAULT NULL,
  `业务` varchar(200) DEFAULT NULL,
  `成立时间` varchar(45) DEFAULT NULL,
  `估值` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='竞品信息';

-- ----------------------------
-- Table structure for t_judiciaaid
-- ----------------------------
DROP TABLE IF EXISTS `t_judiciaaid`;
CREATE TABLE `t_judiciaaid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `被执行人` varchar(45) DEFAULT NULL,
  `股权数额` varchar(45) DEFAULT NULL,
  `执行法院` varchar(45) DEFAULT NULL,
  `执行通知文号` varchar(45) DEFAULT NULL,
  `类型状态` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='司法协助';

-- ----------------------------
-- Table structure for t_judicialsale
-- ----------------------------
DROP TABLE IF EXISTS `t_judicialsale`;
CREATE TABLE `t_judicialsale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `拍卖公告` varchar(200) DEFAULT NULL,
  `拍卖链接` varchar(300) DEFAULT NULL,
  `公告日期` varchar(45) DEFAULT NULL,
  `执行法院` varchar(100) DEFAULT NULL,
  `拍卖标的` varchar(350) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='拍卖公告';

-- ----------------------------
-- Table structure for t_lawsuit
-- ----------------------------
DROP TABLE IF EXISTS `t_lawsuit`;
CREATE TABLE `t_lawsuit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `日期` varchar(45) DEFAULT NULL,
  `裁判文书` varchar(1000) DEFAULT NULL,
  `案由` varchar(200) DEFAULT NULL,
  `案件身份` varchar(1000) DEFAULT NULL,
  `案号` varchar(100) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='法律诉讼';

-- ----------------------------
-- Table structure for t_licensing
-- ----------------------------
DROP TABLE IF EXISTS `t_licensing`;
CREATE TABLE `t_licensing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) DEFAULT NULL,
  `公司id` varchar(45) DEFAULT NULL,
  `许可书文编号` varchar(45) DEFAULT NULL,
  `许可文件名称` varchar(100) DEFAULT NULL,
  `有效期自` varchar(45) DEFAULT NULL,
  `有效期至` varchar(45) DEFAULT NULL,
  `许可机关` varchar(100) DEFAULT NULL,
  `许可内容` varchar(300) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='行政许可【工商局】';

-- ----------------------------
-- Table structure for t_licensingxyzg
-- ----------------------------
DROP TABLE IF EXISTS `t_licensingxyzg`;
CREATE TABLE `t_licensingxyzg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) DEFAULT NULL,
  `公司id` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  `行政许可文书号` varchar(45) DEFAULT NULL,
  `许可决定机关` varchar(100) DEFAULT NULL,
  `许可决定日期` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='行政许可【信用中国】';

-- ----------------------------
-- Table structure for t_listingnotice
-- ----------------------------
DROP TABLE IF EXISTS `t_listingnotice`;
CREATE TABLE `t_listingnotice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `日期` varchar(255) DEFAULT NULL,
  `上市公告` varchar(255) DEFAULT NULL,
  `公告地址` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_mortgage
-- ----------------------------
DROP TABLE IF EXISTS `t_mortgage`;
CREATE TABLE `t_mortgage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `登记日期` varchar(45) DEFAULT NULL,
  `登记号` varchar(45) DEFAULT NULL,
  `被担保债权类型` varchar(45) DEFAULT NULL,
  `被担保债权数额` varchar(45) DEFAULT NULL,
  `登记机关` varchar(45) DEFAULT NULL,
  `状态` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='动产抵押';

-- ----------------------------
-- Table structure for t_patent
-- ----------------------------
DROP TABLE IF EXISTS `t_patent`;
CREATE TABLE `t_patent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) DEFAULT NULL,
  `公司id` varchar(45) DEFAULT NULL,
  `申请公布日` varchar(45) DEFAULT NULL,
  `专利名称` varchar(100) DEFAULT NULL,
  `申请号` varchar(45) DEFAULT NULL,
  `申请公布号` varchar(45) DEFAULT NULL,
  `专利类型` varchar(45) DEFAULT NULL,
  `操作` varchar(200) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='专利信息';

-- ----------------------------
-- Table structure for t_productinfo
-- ----------------------------
DROP TABLE IF EXISTS `t_productinfo`;
CREATE TABLE `t_productinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `产品名称` varchar(200) DEFAULT NULL,
  `产品简称` varchar(45) DEFAULT NULL,
  `产品分类` varchar(45) DEFAULT NULL,
  `领域` varchar(45) DEFAULT NULL,
  `操作` varchar(500) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='产品信息';

-- ----------------------------
-- Table structure for t_project
-- ----------------------------
DROP TABLE IF EXISTS `t_project`;
CREATE TABLE `t_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(255) NOT NULL,
  `项目名称` varchar(255) DEFAULT NULL,
  `年度收入万元` varchar(255) DEFAULT NULL,
  `年度支出万元` varchar(255) DEFAULT NULL,
  `关注领域` varchar(255) DEFAULT NULL,
  `覆盖地域` varchar(255) DEFAULT NULL,
  `详情` varchar(3000) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_publicnotice
-- ----------------------------
DROP TABLE IF EXISTS `t_publicnotice`;
CREATE TABLE `t_publicnotice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `票据号` varchar(45) DEFAULT NULL,
  `票据类型` varchar(45) DEFAULT NULL,
  `票面金额` varchar(45) DEFAULT NULL,
  `公告日期` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公示催告';

-- ----------------------------
-- Table structure for t_punishcreditchina
-- ----------------------------
DROP TABLE IF EXISTS `t_punishcreditchina`;
CREATE TABLE `t_punishcreditchina` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `决定日期` varchar(45) DEFAULT NULL,
  `决定书文号` varchar(200) DEFAULT NULL,
  `处罚名称` varchar(1000) DEFAULT NULL,
  `处罚机关` varchar(200) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='行政处罚 信用中国';

-- ----------------------------
-- Table structure for t_purchasland
-- ----------------------------
DROP TABLE IF EXISTS `t_purchasland`;
CREATE TABLE `t_purchasland` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `土地坐落` varchar(45) DEFAULT NULL,
  `土地用途` varchar(45) DEFAULT NULL,
  `总面积公顷` varchar(45) DEFAULT NULL,
  `行政区` varchar(45) DEFAULT NULL,
  `供应方式` varchar(45) DEFAULT NULL,
  `签订日期` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='购地信息';

-- ----------------------------
-- Table structure for t_recruit
-- ----------------------------
DROP TABLE IF EXISTS `t_recruit`;
CREATE TABLE `t_recruit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `发布时间` varchar(45) DEFAULT NULL,
  `招聘职位` varchar(200) DEFAULT NULL,
  `薪资` varchar(45) DEFAULT NULL,
  `工作经验` varchar(45) DEFAULT NULL,
  `招聘人数` varchar(45) DEFAULT NULL,
  `所在城市` varchar(45) DEFAULT NULL,
  `操作` varchar(1000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='招聘';

-- ----------------------------
-- Table structure for t_report
-- ----------------------------
DROP TABLE IF EXISTS `t_report`;
CREATE TABLE `t_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `年份` varchar(45) DEFAULT NULL,
  `年报` varchar(300) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='公司年报';

-- ----------------------------
-- Table structure for t_risk
-- ----------------------------
DROP TABLE IF EXISTS `t_risk`;
CREATE TABLE `t_risk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `自身风险` varchar(45) DEFAULT NULL,
  `周边风险` varchar(45) DEFAULT NULL,
  `预警提醒` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='天眼风险';

-- ----------------------------
-- Table structure for t_seniorpeople
-- ----------------------------
DROP TABLE IF EXISTS `t_seniorpeople`;
CREATE TABLE `t_seniorpeople` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `姓名` varchar(255) DEFAULT NULL,
  `职务` varchar(255) DEFAULT NULL,
  `持股数` varchar(255) DEFAULT NULL,
  `年龄` varchar(255) DEFAULT NULL,
  `学历` varchar(255) DEFAULT NULL,
  `详情` varchar(3000) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_sharestructure
-- ----------------------------
DROP TABLE IF EXISTS `t_sharestructure`;
CREATE TABLE `t_sharestructure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) DEFAULT NULL,
  `公司id` varchar(11) DEFAULT NULL,
  `时间` varchar(255) DEFAULT NULL,
  `总股本` varchar(255) DEFAULT NULL,
  `A股总股本` varchar(255) DEFAULT NULL,
  `流通A股` varchar(255) DEFAULT NULL,
  `限售A股` varchar(255) DEFAULT NULL,
  `H股总股本` varchar(255) DEFAULT NULL,
  `流通H股` varchar(255) DEFAULT NULL,
  `限售H股` varchar(255) DEFAULT NULL,
  `变动原因` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_softwarecopyright
-- ----------------------------
DROP TABLE IF EXISTS `t_softwarecopyright`;
CREATE TABLE `t_softwarecopyright` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `批准日期` varchar(45) DEFAULT NULL,
  `软件全称` varchar(100) DEFAULT NULL,
  `软件简称` varchar(100) DEFAULT NULL,
  `登记号` varchar(45) DEFAULT NULL,
  `分类号` varchar(45) DEFAULT NULL,
  `版本号` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='软件著作权';

-- ----------------------------
-- Table structure for t_staff
-- ----------------------------
DROP TABLE IF EXISTS `t_staff`;
CREATE TABLE `t_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `主要人员` varchar(45) DEFAULT NULL,
  `职位` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='主要人员';

-- ----------------------------
-- Table structure for t_supervisor
-- ----------------------------
DROP TABLE IF EXISTS `t_supervisor`;
CREATE TABLE `t_supervisor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) DEFAULT NULL,
  `公司id` varchar(255) DEFAULT NULL,
  `姓名` varchar(255) DEFAULT NULL,
  `性别` varchar(255) DEFAULT NULL,
  `年度会议次数` varchar(255) DEFAULT NULL,
  `工作单位及职务` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_taxcredit
-- ----------------------------
DROP TABLE IF EXISTS `t_taxcredit`;
CREATE TABLE `t_taxcredit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `年份` varchar(45) DEFAULT NULL,
  `纳税评级` varchar(45) DEFAULT NULL,
  `类型` varchar(45) DEFAULT NULL,
  `纳税人识别号` varchar(45) DEFAULT NULL,
  `评价单位` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='税收业务';

-- ----------------------------
-- Table structure for t_teammember
-- ----------------------------
DROP TABLE IF EXISTS `t_teammember`;
CREATE TABLE `t_teammember` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `姓名` varchar(45) DEFAULT NULL,
  `任职` varchar(45) DEFAULT NULL,
  `任职经历` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='团队核心';

-- ----------------------------
-- Table structure for t_telepermission
-- ----------------------------
DROP TABLE IF EXISTS `t_telepermission`;
CREATE TABLE `t_telepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `许可证号` varchar(45) DEFAULT NULL,
  `业务范围` varchar(300) DEFAULT NULL,
  `是否有效` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) NOT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='电信许可';

-- ----------------------------
-- Table structure for t_tentradablenum
-- ----------------------------
DROP TABLE IF EXISTS `t_tentradablenum`;
CREATE TABLE `t_tentradablenum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `机构或基金` varchar(255) DEFAULT NULL,
  `持有数量` varchar(255) DEFAULT NULL,
  `持股变化股` varchar(255) DEFAULT NULL,
  `占股本比例` varchar(255) DEFAULT NULL,
  `实际增减持` varchar(255) DEFAULT NULL,
  `股份类型` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_tminfo
-- ----------------------------
DROP TABLE IF EXISTS `t_tminfo`;
CREATE TABLE `t_tminfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `申请日期` varchar(45) DEFAULT NULL,
  `商标` varchar(300) DEFAULT NULL,
  `商标名称` varchar(45) DEFAULT NULL,
  `注册号` varchar(45) DEFAULT NULL,
  `类别` varchar(45) DEFAULT NULL,
  `流程状态` varchar(200) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商标信息';

-- ----------------------------
-- Table structure for t_toptennum
-- ----------------------------
DROP TABLE IF EXISTS `t_toptennum`;
CREATE TABLE `t_toptennum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `机构或基金` varchar(255) DEFAULT NULL,
  `持有数量` varchar(255) DEFAULT NULL,
  `持股变化股` varchar(255) DEFAULT NULL,
  `占股本比例` varchar(255) DEFAULT NULL,
  `实际增减持` varchar(255) DEFAULT NULL,
  `股份类型` varchar(255) DEFAULT NULL,
  `模块id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_towntax
-- ----------------------------
DROP TABLE IF EXISTS `t_towntax`;
CREATE TABLE `t_towntax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `发布日期` varchar(45) DEFAULT NULL,
  `纳税人识别号` varchar(45) DEFAULT NULL,
  `欠税税种` varchar(45) DEFAULT NULL,
  `当前发生的欠税额` varchar(45) DEFAULT NULL,
  `欠税余额` varchar(45) DEFAULT NULL,
  `税务机关` varchar(45) DEFAULT NULL,
  `操作` varchar(3000) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='欠税公告';

-- ----------------------------
-- Table structure for t_volatilitynum
-- ----------------------------
DROP TABLE IF EXISTS `t_volatilitynum`;
CREATE TABLE `t_volatilitynum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(255) NOT NULL,
  `公司id` varchar(255) NOT NULL,
  `股票名` varchar(255) DEFAULT NULL,
  `股票id` varchar(255) DEFAULT NULL,
  `今开` varchar(255) DEFAULT NULL,
  `最高` varchar(255) DEFAULT NULL,
  `涨停` varchar(255) DEFAULT NULL,
  `昨收` varchar(255) DEFAULT NULL,
  `最低` varchar(255) DEFAULT NULL,
  `跌停` varchar(255) DEFAULT NULL,
  `总市值` varchar(255) DEFAULT NULL,
  `流通市值` varchar(255) DEFAULT NULL,
  `成交量` varchar(255) DEFAULT NULL,
  `成交额` varchar(255) DEFAULT NULL,
  `市净率` varchar(255) DEFAULT NULL,
  `市盈率动` varchar(255) DEFAULT NULL,
  `振幅` varchar(255) DEFAULT NULL,
  `换手` varchar(255) DEFAULT NULL,
  `模块id` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_wechat
-- ----------------------------
DROP TABLE IF EXISTS `t_wechat`;
CREATE TABLE `t_wechat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司id` varchar(45) NOT NULL,
  `公司名称` varchar(45) NOT NULL,
  `微信公众号名` varchar(45) NOT NULL,
  `微信号` varchar(45) NOT NULL,
  `功能介绍` varchar(300) DEFAULT NULL,
  `详情` varchar(2000) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信工作公众号';

-- ----------------------------
-- Table structure for t_workscopyright
-- ----------------------------
DROP TABLE IF EXISTS `t_workscopyright`;
CREATE TABLE `t_workscopyright` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `公司名称` varchar(45) NOT NULL,
  `公司id` varchar(45) NOT NULL,
  `作品名称` varchar(100) DEFAULT NULL,
  `登记号` varchar(45) DEFAULT NULL,
  `类别` varchar(45) DEFAULT NULL,
  `创作完成日期` varchar(45) DEFAULT NULL,
  `登记日期` varchar(45) DEFAULT NULL,
  `首次发布日期` varchar(45) DEFAULT NULL,
  `模块id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='作品著作权';
