# from scrapy.cmdline import  execute
# execute(['scrapy','crawl','worksCopyrightSpider'])

#coding=utf8
# -*- coding: utf-8 -*-
import os
# 必须先加载项目settings配置
# project需要改为你的工程名字（即settings.py所在的目录名字）
os.environ.setdefault('SCRAPY_SETTINGS_MODULE', 'tianyan.settings')
import scrapy
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
process = CrawlerProcess(get_project_settings())

# 指定多个spider
# process.crawl("VolatilityNumSpider")
# process.crawl("IntroductionSpider")
# process.crawl("BaseInfoSpider")
# process.crawl("SerniorPeopleSpider")
# process.crawl("riskSpider")
# process.crawl("AnnouncementSpider")
# process.crawl("TopTenNumSpider")
# process.crawl("TenTradableNumSpider")
# process.crawl("ShareStructureSpider")
# process.crawl("BonusSpider")
# process.crawl("EquityChangeSpider")
# process.crawl("staffSpider")
# process.crawl("holderSpider")
# process.crawl("investSpider")
# process.crawl("changeSpider")
# process.crawl('ReportSpider')
# process.crawl("DirectorSpider")
# process.crawl("SupervisorSpider")
# process.crawl("branchSpider")
# process.crawl("announceSpdier")
# process.crawl("lawsuitSpider")
# process.crawl("courtSpider")
# process.crawl("DishonestSpider")
# process.crawl("ExecutionSpider")
# process.crawl("JudicialAidSpider")
# process.crawl("firmProductSpider")
# process.crawl("InvestEventSpider")
# process.crawl("jingpinSpider")
# process.crawl("ProjectSpider")
# process.crawl("recruitSpider")
# process.crawl("AbnormalSpider")
# process.crawl("punishCreditchinaSpider")
# process.crawl("IllegaSpider")
# process.crawl("EquitySpider")
# process.crawl("MortgageSpider")
# process.crawl("TownTaxSpider")
# process.crawl("JudicialSaleSpdier")
# process.crawl("ClearingCountSpider")
# process.crawl("PublicNoticeSpider")
# process.crawl("AnnualCheckSpider")
# process.crawl("FinanceSpider")
# process.crawl("FinancingSpider")
# process.crawl("teamMemberSpider")
# process.crawl("taxcreditSpider")
# process.crawl("LicensingSpider")
# process.crawl("LicensingXyzgSpider")
# process.crawl("CheckSpider")
# process.crawl("cretificateSpider")
# process.crawl("bidSpider")
# process.crawl("productInfoSpdier")
# process.crawl("wechatSpider")
# process.crawl("importAndExprotSpider")
# process.crawl("BondSpider")
# process.crawl("PurchaslandSpider")
# process.crawl("TelePermissionSpider")
# process.crawl("TmInfoSpider")
# process.crawl("patentSpider")
# process.crawl("copyrightSpider")
# process.crawl("worksCopyrightSpider")
# process.crawl("icpSpider")
# process.crawl("ShareStructureSpider")

# 执行所有 spider
# for spider_name in process.spider_loader.list():
#     # print spider_name
#     process.crawl(spider_name)

process.start()

