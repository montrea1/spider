import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import  ShareStructureItem

# 股本结构
class ShareStructureSpider(scrapy.Spider):
    name = 'ShareStructureSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls = config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.ShareStructurePipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "股本结构" in div_titles:
            times = select.xpath("//div[@id='_container_shareStructure']//div[@class='tab-time mb20']//div/text()")
            for time in times:
                date = "".join(time.extract())
                page_url = "https://www.tianyancha.com/stock/shareStructure.xhtml?graphId=%s&time=%s" % (
                config.company_id, date)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                     dont_filter=True)

    def parse_content(self, response):
        html_str = response.text
        select = Selector(text=html_str)
        item = ShareStructureItem()
        table = select.xpath(".//table/tbody/tr")
        for tr in table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "股本结构"
            item['时间'] = "".join(tr.xpath("./td[2]//text()").extract())
            item['总股本'] = "".join(tr.xpath("./td[3]//text()").extract())
            item['A股总股本'] = "".join(tr.xpath("./td[4]//text()").extract())
            item['流通A股'] = "".join(tr.xpath("./td[4]//text()").extract())
            item['限售A股'] = "".join(tr.xpath("./td[5]//text()").extract())
            item['H股总股本'] = "".join(tr.xpath("./td[6]//text()").extract())
            item['流通H股'] = "".join(tr.xpath("./td[7]//text()").extract())
            item['限售H股'] = "".join(tr.xpath("./td[8]//text()").extract())
            item['变动原因'] = "".join(tr.xpath("./td[9]//text()").extract())
            yield item





