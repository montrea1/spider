import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import BondItem, PublicNoticeItem, InvestEventItem

# 投资事件
class InvestEventSpider(scrapy.Spider):
    name = 'InvestEventSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.InvestEventPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "投资事件"in div_titles:
               page_url = "https://www.tianyancha.com/pagination/touzi.xhtml?pn=1&name=%s" % (self.company_name)
               yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                     dont_filter=True)

    def parse_content(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = InvestEventItem()
        table = select.xpath(".//table/tbody/tr")
        for tr in table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "投资事件"
            date ="".join(tr.xpath("./td[2]//text()").extract())
            item['时间'] = date
            rotation = "".join(tr.xpath("./td[3]//text()").extract())
            item['轮次'] = rotation
            sum = "".join(tr.xpath("./td[4]//text()").extract())
            item['金额'] = sum
            investor= "".join(tr.xpath("./td[5]//text()").extract())
            item['投资方']=investor
            product = "".join(tr.xpath("./td[6]/table//a/text()").extract())
            item['产品'] = product
            area = "".join(tr.xpath("./td[7]//text()").extract())
            item['地区'] = area
            industry = "".join(tr.xpath("./td[8]//text()").extract())
            item['行业'] = industry
            service = "".join(tr.xpath("./td[9]//text()").extract())
            item['业务'] = service
            yield item

        next_page=select.xpath("//div[@class='company_pager']/ul//li/a[@class='num -next']/@onclick")
        if len(next_page )!=0:
            num="".join(next_page.re(r'\d'))
            page_url = "https://www.tianyancha.com/pagination/touzi.xhtml?pn=%s&name=%s" % (num,self.company_name)
            yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                 dont_filter=True)




