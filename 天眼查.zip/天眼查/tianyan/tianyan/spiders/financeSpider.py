import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import  FinanceItem

# 财务年度
class FinanceSpider(scrapy.Spider):
    name = 'FinanceSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.FinancePipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)
        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        if select.xpath(".//div[@id='nav-main-finance']") is not None:
            html_str=response.text
            select=Selector(text=html_str)
            years=select.xpath("//div[@id='nav-main-finance']/div[@class='drop-down'][2]/div[@class='content']//div[@class='item']//text()")
            for year in years:
                year_str="".join(year.re(r'\d'))
                page_url = "https://www.tianyancha.com/pagination/finance.xhtml?id=%s&year=%s" % (config.company_id,year_str)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                     dont_filter=True)

    def parse_content(self, response):
        html_str = response.text
        select = Selector(text=html_str)
        item=FinanceItem()
        item['公司名称'] = self.company_name
        item['公司id'] = config.company_id
        item['模块id'] = "财务年度"
        trs=select.xpath("//div[@id='final_resultList']//table//tbody//tr")
        for tr in trs:
            names=tr.xpath("./td[1]//text()")
            contents=tr.xpath("./td[2]//text()")
            for i in range(len(names)):
                name="".join(names[i].extract())
                content="".join(contents[i].extract())
                if name!="":
                    item[name] = content
        yield item







