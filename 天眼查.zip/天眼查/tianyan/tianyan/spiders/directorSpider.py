import scrapy
from scrapy import Selector

import config
from tianyan.items import DirectorItem

# 理事会
class DirectorSpider(scrapy.Spider):
    name = 'DirectorSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.DirectorPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())


        if select.xpath(".//div[@id='_container_director']") is not None:
               page_url = "https://www.tianyancha.com/pagination/director.xhtml?pn=1&id=%s" % (config.company_id)
               yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                     dont_filter=True)

    def parse_content(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = DirectorItem()
        table = select.xpath(".//table/tbody/tr")
        for tr in table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "理事会"
            item['姓名'] ="".join(tr.xpath("./td[2]//text()").extract())
            item['理事会职务'] ="".join(tr.xpath("./td[3]//text()").extract())
            item['性别'] ="".join(tr.xpath("./td[4]//text()").extract())
            item['年度会议次数']="".join(tr.xpath("./td[5]//text()").extract())
            item['工作单位及职务'] ="".join(tr.xpath("./td[6]//text()").extract())
            yield item

        next_page=select.xpath("//div[@class='company_pager']/ul//li/a[@class='num -next']/@onclick")
        if len(next_page )!=0:
            num="".join(next_page.re(r'\d'))
            page_url = "https://www.tianyancha.com/pagination/director.xhtml?pn=%s&id=%s" % (num,config.company_id)
            yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                 dont_filter=True)




