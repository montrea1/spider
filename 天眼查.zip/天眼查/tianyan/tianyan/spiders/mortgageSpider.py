import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import BondItem, PublicNoticeItem, InvestEventItem, MortgageItem

# 动产抵押
class MortgageSpider(scrapy.Spider):
    name = 'MortgageSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.MortgagePipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "nav-main-mortgageCount" in div_ids:
               page_url = "https://www.tianyancha.com/pagination/mortgage.xhtml?pn=1&name=%s" % (self.company_name)
               yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                     dont_filter=True)

    def parse_content(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = MortgageItem()
        table = select.xpath(".//table/tbody/tr")
        for tr in table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "动产抵押"
            record_date ="".join(tr.xpath("./td[2]//text()").extract())
            item['登记日期'] = record_date
            record_code = "".join(tr.xpath("./td[3]//text()").extract())
            item['登记号'] = record_code
            mortgage_type = "".join(tr.xpath("./td[4]//text()").extract())
            item['被担保债权类型'] = mortgage_type
            mortgage_sum= "".join(tr.xpath("./td[5]//text()").extract())
            item['被担保债权数额']=mortgage_sum
            product = "".join(tr.xpath("./td[6]//text()").extract())
            item['登记机关'] = product
            state = "".join(tr.xpath("./td[7]//text()").extract())
            item['状态'] = state
            operation = "".join(tr.xpath("./td[8]//text()").extract())
            item['操作'] = operation
            yield item

        next_page=select.xpath("//div[@class='company_pager']/ul//li/a[@class='num -next']/@onclick")
        if len(next_page )!=0:
            num="".join(next_page.re(r'\d'))
            page_url = "https://www.tianyancha.com/pagination/mortgage.xhtml?pn=%s&name=%s" % (num,self.company_name)
            yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                 dont_filter=True)




