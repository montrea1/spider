# -*- coding: utf-8 -*-
import scrapy
import re
from scrapy import Selector

from tools import config
from tianyan.items import  BaseInfoItem
from tools.numberMaps import convert

# 基本信息
class BaseInfoSpider(scrapy.Spider):
    name = 'BaseInfoSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
                'ITEM_PIPELINES': {
                    'tianyan.pipelines.BaseinfoPipeline': 200
                },
             'DEFAULT_REQUEST_HEADERS':{"Accept": " text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "Accept-Encoding": " gzip, deflate, br",
            "Accept-Language": " zh-CN,zh;q=0.9",
            "Connection": " keep-alive",
            "Cookie": config.Cookies,
            "Host": " www.tianyancha.com",
            "Referer": " https://www.tianyancha.com/login?from=https%3A%2F%2Fwww.tianyancha.com%2Fsearch%3Fbase%3Dgd",
            "Upgrade-Insecure-Requests":"1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36"
            },
        'DOWMLOAD_DELY': 5,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, cookies=config.Cookies)

    def parse(self, response):
        html_str=response.text
        select=Selector(text=html_str)

        item=BaseInfoItem()

        # 基本信息
        phone="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='f0'][1]/div[@class='in-block'][1]/span[2]/text()").extract())
        item['电话']=phone
        email="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='f0'][1]/div[@class='in-block'][2]/span[2]/text()").extract())
        item['邮箱']=email

        site="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='f0'][2]/div[@class='in-block'][1]/a/@href").extract())
        item['网址']=site
        site_none=select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='f0'][2]/div[@class='in-block'][1]/span[2]/text()").extract()
        if  "暂无信息" in site_none:
            item['网址'] = "".join(site_none)

        address="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='f0'][2]/div[@class='in-block'][2]/text()").extract())
        address_detail="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='f0'][2]/div[@class='in-block'][2]/span[@class='pl5']/script/text()").re(r'\"(\S+)\"'))
        if  address_detail !="":
            item['地址']=address_detail
        else:
          item['地址'] = address

        summary="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='summary']/span[2]/text()").extract())
        summary_detail="".join(select.xpath("//*[@id='company_web_top']/div[@class='box']/div[@class='content']/div[5]/div[@class='summary']/script/text()").re(r'\S'))
        if summary_detail !="":
            item['简介']=summary_detail
        else:
            item['简介']=summary

        # 注册时间
        regTime=''.join(select.xpath("//div[@id='_container_baseInfo']/table[@class='table']/tbody/tr[2]/td/div[2]/text/text()").extract())
        item['注册时间']=convert(regTime)
        # 注册资本
        regCapital="".join(select.xpath("//div[@id='_container_baseInfo']/table[@class='table']/tbody/tr[1]/td[2]/div[2]/text/text()").extract())
        item['注册资本']=convert(regCapital)
        # 法人代表
        representative="".join(select.xpath("//div[@id='_container_baseInfo']/table[@class='table']//tr[1]/td[@class='left-col shadow']//div[@class='name']//text()").extract())
        item['法定代表人']=representative
        # 公司名称
        company_name= self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())
        item['公司名称']=company_name
        item['公司id']=config.company_id
        item['模块id']="基本信息"
        # 公司状态
        company_state="".join(select.xpath("//div[@id='_container_baseInfo']/table//tr[3]//div[@class='num-opening']/text()").extract())
        item['公司状态']=company_state

        # 详情
        detail_name_list01=select.xpath("//div[@id='_container_baseInfo']/table[@class='table -striped-col -border-top-none']//tr/td[1]/text()").extract()
        detail_name_list02=select.xpath("//div[@id='_container_baseInfo']/table[@class='table -striped-col -border-top-none']//tr/td[3]/text()").extract()
        detail_name_list=detail_name_list01+detail_name_list02

        detail_content_list01=select.xpath("//div[@id='_container_baseInfo']/table[@class='table -striped-col -border-top-none']//tr/td[2]//text()").extract()
        detail_content_list02 = select.xpath("//div[@id='_container_baseInfo']/table[@class='table -striped-col -border-top-none']//tr/td[4]//text()").extract()
        detail_content_list=detail_content_list01+detail_content_list02
        if "..." in detail_content_list:
            detail_content_list.remove("...")
        if "详情" in detail_content_list:
            detail_content_list.remove("详情")
        if "附近公司" in detail_content_list:
            detail_content_list.remove("附近公司")

        for i in range(len(detail_name_list)):
            if "".join(detail_name_list[i])=="核准日期" :
                item[detail_name_list[i]] =convert("".join(detail_content_list[i]))
            else:
                item[detail_name_list[i]] ="".join(detail_content_list[i])
        item['股权结构图']="".join(select.xpath("//*[@id='_container_baseInfo']/table[1]/tbody/tr[1]/td[3]/div[1]/img/@src").extract())
        yield item
