import urllib

import requests
import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import StaffItem, HolderItem

# 主要人员
class holderSpider(scrapy.Spider):
    name = 'holderSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.HolderPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'DOWMLOAD_DELY': 10,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "主要人员"in div_titles:
            staff_table = select.xpath("//div[@id='_container_staff']/div[@class='wechat-list']/div[@class='wechat']")
            staff_ul = select.xpath("//div[@id='_container_staff']//div[@class='company_pager']/ul")
            url_list = []
            # 多页表格
            if len("".join(staff_ul.extract())) != 0:
                # 多于一行ul
                if len("".join(staff_ul.xpath("./li/a[@class='num -end']").extract())) != 0:
                    page_count = "".join(staff_ul.xpath(".//li/a[@class='num -end']/text()").re(r'\d+'))
                    for page in range(int(page_count)):
                        page_url = "https://www.tianyancha.com/pagination/holder.xhtml?pn=%s&id=%s" % (
                            page + 1, config.company_id)
                        url_list.append(page_url)
                # 少于一行ul
                else:
                    page_count = staff_ul.xpath(
                        ".//li/a[@class='num ']/text()|./li/a[@class='num -current']/text()").extract()
                    for page in page_count:
                        page_url = "https://www.tianyancha.com/pagination/holder.xhtml?pn=%s&id=%s" % (
                            page, config.company_id)
                        url_list.append(page_url)
                if len(url_list) != 0:
                    for url in url_list:
                        yield scrapy.Request(url=url, cookies=config.Cookies, callback=self.parse_holder,
                                             dont_filter=True)
            # 单页表格
            else:
                page_url = "https://www.tianyancha.com/pagination/holder.xhtml?pn=1&id=%s" % (config.company_id)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_holder,
                                     dont_filter=True)

    def parse_holder(self, response):
        html_str = response.text
        select = Selector(text=html_str)
        holder_table = select.xpath("//table/tbody/tr")
        item = HolderItem()
        for holder_tr in holder_table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "股东信息"
            holder=holder_tr.xpath("./td[2]//div[@class='dagudong']/a/text()").extract_first()
            item['股东']=holder
            rate=holder_tr.xpath("./td[3]//span[@class='num-investment-rate']/text()").extract_first()
            item['出资比例']=rate
            contribution = holder_tr.xpath("./td[4]/div/span/text()").extract_first()
            item['认缴出资']=contribution
            date=holder_tr.xpath("./td[5]//text()").extract_first()
            item['出资时间']=date
            yield item
