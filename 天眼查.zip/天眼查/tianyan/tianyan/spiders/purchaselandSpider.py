import scrapy
import re
from scrapy import Selector

import config
from items import PurchaselandItem

# 购地信息
class PurchaslandSpider(scrapy.Spider):
    name = 'PurchaslandSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls = config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.PurchaslandPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'DOWMLOAD_DELY': 10,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "购地信息" in div_titles:
            purchaseland_ul = select.xpath(".//div[@id='_container_purchaselandV2']//div[@class='company_pager']/ul")
            url_list = []
            # 多页表格
            if len("".join(purchaseland_ul.extract())) != 0:
                # 多于一行ul
                if len("".join(purchaseland_ul.xpath("./li/a[@class='num -end']").extract())) != 0:
                    page_count = "".join(purchaseland_ul.xpath(".//li/a[@class='num -end']/text()").re(r'\d+'))
                    for page in range(int(page_count)):
                        page_url = "https://www.tianyancha.com/pagination/purchaselandV2.xhtml?pn=%s&name=%s" % (
                            page, self.company_name)
                        url_list.append(page_url)
                # 少于一行ul
                else:
                    page_count = purchaseland_ul.xpath(
                        ".//li/a[@class='num ']/text()|./li/a[@class='num -current']/text()").extract()
                    for page in page_count:
                        page_url = "https://www.tianyancha.com/pagination/purchaselandV2.xhtml?pn=%s&name=%s" % (
                            page, self.company_name)
                        url_list.append(page_url)
                if len(url_list) != 0:
                    for url in url_list:
                        yield scrapy.Request(url=url, cookies=config.Cookies, callback=self.parse_purchaseland,
                                             dont_filter=True)
            # 单页表格
            else:
                page_url = "https://www.tianyancha.com/pagination/purchaselandV2.xhtml?pn=1&name=%s" % ( self.company_name)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_purchaseland,
                                     dont_filter=True)

    def  parse_purchaseland(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = PurchaselandItem()
        purchaseland_table = select.xpath(".//table/tbody/tr")
        for purchaseland_tr in purchaseland_table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "购地信息"
            purchaseland_site = "".join(purchaseland_tr.xpath("./td[2]/span//text()").extract())
            item['土地坐落'] = purchaseland_site
            purchaseland_purpose = "".join(purchaseland_tr.xpath("./td[3]//text()").extract())
            item['土地用途'] = purchaseland_purpose
            purchaseland_area = "".join(purchaseland_tr.xpath("./td[4]//text()").extract())
            item['总面积公顷'] = purchaseland_area
            supply_mode = "".join(purchaseland_tr.xpath("./td[5]//text()").extract())
            item['供应方式'] = supply_mode
            government="".join(purchaseland_tr.xpath("./td[6]//text()").extract())
            item['行政区']=government
            date_siging = "".join(purchaseland_tr.xpath("./td[7]//text()").extract())
            item['签订日期'] = date_siging
            yield item