import scrapy
import re
from scrapy import Selector

import config
from items import CopyrightSoftwareItem

# 软件著作权
class CopyrightSpider(scrapy.Spider):
    name = 'copyrightSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls = config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.CopyrightPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'DOWMLOAD_DELY': 10,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "软件著作权" in div_titles:
            copyright_ul = select.xpath(".//div[@id='_container_patent']//div[@class='company_pager']/ul")
            url_list = []
            # 多页表格
            if len("".join(copyright_ul.extract())) != 0:
                # 多于一行ul
                if len("".join(copyright_ul.xpath("./li/a[@class='num -end']").extract())) != 0:
                    page_count = "".join(copyright_ul.xpath(".//li/a[@class='num -end']/text()").re(r'\d+'))
                    for page in range(int(page_count)):
                        page_url = "https://www.tianyancha.com/pagination/copyright.xhtml?pn=%s&id=%s" % (
                            page, config.company_id)
                        url_list.append(page_url)
                # 少于一行ul
                else:
                    page_count = copyright_ul.xpath(
                        ".//li/a[@class='num ']/text()|./li/a[@class='num -current']/text()").extract()
                    for page in page_count:
                        page_url = "https://www.tianyancha.com/pagination/copyright.xhtml?pn=%s&id=%s" % (
                            page, config.company_id)
                        url_list.append(page_url)
                if len(url_list) != 0:
                    for url in url_list:
                        yield scrapy.Request(url=url, cookies=config.Cookies, callback=self.parse_copyrightSoftware,
                                             dont_filter=True)
            # 单页表格
            else:
                page_url = "https://www.tianyancha.com/pagination/copyright.xhtml?pn=1&id=%s" % ( config.company_id)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_copyrightSoftware,
                                     dont_filter=True)

    def parse_copyrightSoftware(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = CopyrightSoftwareItem()
        copyright_table = select.xpath(".//table/tbody/tr")
        for copyright_tr in copyright_table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "软件著作权"
            approval_date = "".join(copyright_tr.xpath("./td[2]//text()").extract())
            item['批准日期'] = approval_date
            software_name = "".join(copyright_tr.xpath("./td[3]//text()").extract())
            item['软件全称'] = software_name
            software_abbreviation = "".join(copyright_tr.xpath("./td[4]//text()").extract())
            item['软件简称'] = software_abbreviation
            register_number = "".join(copyright_tr.xpath("./td[5]//text()").extract())
            item['登记号'] = register_number
            category_number = "".join(copyright_tr.xpath("./td[6]//text()").extract())
            item['分类号'] = category_number
            vision_number = "".join(copyright_tr.xpath("./td[7]//a/@href").extract())
            item['版本号'] = vision_number
            operation = "".join(copyright_tr.xpath("./td[8]//script/text()").extract())
            item['操作'] = operation
            yield item
