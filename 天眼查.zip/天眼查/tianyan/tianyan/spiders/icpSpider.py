import scrapy
import re
from scrapy import Selector

import config
from items import IcpItem

# 网站备案
class IcpSpider(scrapy.Spider):
    name = 'icpSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls = config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.IcpPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'DOWMLOAD_DELY': 10,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "网站备案" in div_titles:
            website_ul = select.xpath(".//div[@id='_container_icp']//div[@class='company_pager']/ul")
            url_list = []
            # 多页表格
            if len("".join(website_ul.extract())) != 0:
                # 多于一行ul
                if len("".join(website_ul.xpath("./li/a[@class='num -end']").extract())) != 0:
                    page_count = "".join(website_ul.xpath(".//li/a[@class='num -end']/text()").re(r'\d+'))
                    for page in range(int(page_count)):
                        page_url = "https://www.tianyancha.com/pagination/icp.xhtml?pn=%s&id=%s" % (
                            page, config.company_id)
                        url_list.append(page_url)
                # 少于一行ul
                else:
                    page_count = website_ul.xpath(
                        ".//li/a[@class='num ']/text()|./li/a[@class='num -current']/text()").extract()
                    for page in page_count:
                        page_url = "https://www.tianyancha.com/pagination/icp.xhtml?pn=%s&id=%s" % (
                            page, config.company_id)
                        url_list.append(page_url)
                if len(url_list) != 0:
                    for url in url_list:
                        yield scrapy.Request(url=url, cookies=config.Cookies, callback=self.parse_icp,
                                             dont_filter=True)
            # 单页表格
            else:
                page_url = "https://www.tianyancha.com/pagination/icp.xhtml?pn=1&id=%s" % (config.company_id)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_icp,
                                     dont_filter=True)

    def parse_icp(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = IcpItem()
        webiste_table = select.xpath(".//table/tbody/tr")
        for webiste_tr in webiste_table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "法院公告"
            audit_date = "".join(webiste_tr.xpath("./td[2]//text()").extract())
            item['审核时间'] = audit_date
            website_name = "".join(webiste_tr.xpath("./td[3]//text()").extract())
            item['网站名称'] = website_name
            website_homepage = "".join(webiste_tr.xpath("./td[4]//text()").extract())
            item['网站首页'] = website_homepage
            domain = "".join(webiste_tr.xpath("./td[5]//text()").extract())
            item['域名'] = domain
            record_number = "".join(webiste_tr.xpath("./td[6]//text()").extract())
            item['备案号'] = record_number
            state = "".join(webiste_tr.xpath("./td[7]//a/@href").extract())
            item['状态'] = state
            company_type = "".join(webiste_tr.xpath("./td[7]//a/@href").extract())
            item['单位性质'] = company_type
            yield item
