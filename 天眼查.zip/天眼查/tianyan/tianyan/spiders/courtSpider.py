
import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import  CourtItem

# 法院公告
class CourtSpider(scrapy.Spider):
    name = 'courtSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.CourtPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'DOWMLOAD_DELY': 10,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "法院公告"in div_titles:
            branch_ul = select.xpath("//div[@id='_container_court']//div[@class='company_pager']/ul")
            url_list = []
            # 多页表格
            if len("".join(branch_ul.extract())) != 0:
                # 多于一行ul
                if len("".join(branch_ul.xpath("./li/a[@class='num -end']").extract())) != 0:
                    page_count = "".join(branch_ul.xpath(".//li/a[@class='num -end']/text()").re(r'\d+'))
                    for page in range(int(page_count)):
                        page_url = "https://www.tianyancha.com/pagination/court.xhtml?pn=%s&name=%s" % (
                            page + 1, self.company_name)
                        url_list.append(page_url)
                # 少于一行ul
                else:
                    page_count = branch_ul.xpath(
                        ".//li/a[@class='num ']/text()|./li/a[@class='num -current']/text()").extract()
                    for page in page_count:
                        page_url = "https://www.tianyancha.com/pagination/court.xhtml?pn=%s&name=%s" % (
                            page, self.company_name)
                        url_list.append(page_url)
                if len(url_list) != 0:
                    for url in url_list:
                        yield scrapy.Request(url=url, cookies=config.Cookies, callback=self.parse_court,
                                             dont_filter=True)
            # 单页表格
            else:
                page_url = "https://www.tianyancha.com/pagination/court.xhtml?pn=1&name=%s" % (self.company_name)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_court,
                                     dont_filter=True)

    def parse_court(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = CourtItem()
        court_table = select.xpath(".//table/tbody/tr")
        for court_tr in court_table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "法院公告"
            date="".join(court_tr.xpath("./td[2]//text()").extract())
            item['公告时间']=date
            plaintiff="".join(court_tr.xpath("./td[3]//text()").extract())
            item['上诉方']=plaintiff
            defendant="".join(court_tr.xpath("./td[4]/span//text()").extract())
            item['被诉方']=defendant
            announcement_type="".join(court_tr.xpath("./td[5]/span//text()").re(r'\S+'))
            item['公告类型']=announcement_type
            court="".join(court_tr.xpath("./td[6]/span//text()").extract())
            item['法院']=court
            operation="".join(court_tr.xpath("./td[7]//a/@href").extract())
            item['操作']=operation
            yield item