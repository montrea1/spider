import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import  TopTemNumItem

# 十大股东
class TopTenNumSpider(scrapy.Spider):
    name = 'TopTenNumSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.TopTenNumPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "十大股东" in div_titles:
            times=select.xpath("//div[@id='_container_shareStructure']//div[@class='tab-time mb20']//div/text()")
            for time in times:
                date="".join(time.extract())
                page_url = "https://www.tianyancha.com/stock/shareholder.xhtml?graphId=%s&type=1&time=%s" % (config.company_id,date)
                yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
                                     dont_filter=True)

    def parse_content(self,response):
        html_str = response.text
        select = Selector(text=html_str)
        item = TopTemNumItem()
        table = select.xpath(".//table/tbody/tr")
        for tr in table:
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "十大股东"
            item['机构或基金'] ="".join(tr.xpath("./td[2]//text()").extract())
            item['持有数量'] = "".join(tr.xpath("./td[3]//text()").extract())
            item['持股变化股'] = "".join(tr.xpath("./td[4]//text()").extract())
            item['占股本比例'] = "".join(tr.xpath("./td[4]//text()").extract())
            item['实际增减持'] = "".join(tr.xpath("./td[5]//text()").extract())
            item['股份类型'] = "".join(tr.xpath("./td[6]//text()").extract())
            yield item

        # next_page=select.xpath("//div[@class='company_pager']/ul//li/a[@class='num -next']/@onclick")
        # if len(next_page )!=0:
        #     num="".join(next_page.re(r'\d'))
        #     page_url = "https://www.tianyancha.com/pagination/announcement.xhtml?pn=%s&id=%s" % (num,config.company_id)
        #     yield scrapy.Request(url=page_url, cookies=config.Cookies, callback=self.parse_content,
        #                          dont_filter=True)




