import scrapy
import re
from scrapy import Selector

import config
from tianyan.items import  VolatilityNumItem

# 股票行情
class VolatilityNumSpider(scrapy.Spider):
    name = 'VolatilityNumSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.VolatilityNumPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)
        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "股票行情" in div_titles:
            html_str=response.text
            select=Selector(text=html_str)
            item=VolatilityNumItem()
            item['公司名称'] = self.company_name
            item['公司id'] = config.company_id
            item['模块id'] = "股票行情"
            item['股票名']="".join(select.xpath("//div[@id='_container_volatilityNum']/table/thead//div[@class='stock']/span[@class='left']/span[1]//text()").extract_first())
            item['股票id']="".join(select.xpath("//div[@id='_container_volatilityNum']/table/thead//div[@class='stock']/span[@class='left']/span[2]//text()").re(r'\d'))
            trs=select.xpath("//div[@id='_container_volatilityNum']//table//tbody//tr")
            for tr in trs:
                names=tr.xpath("./td[1]//text()|./td[3]//text()|./td[5]//text()")
                contents=tr.xpath("./td[2]//text()|./td[4]//text()|./td[6]//text()")
                for i in range(len(names)):
                    name="".join(names[i].extract())
                    content="".join(contents[i].extract())
                    if name!="":
                        if "市盈率（动）" == name:
                            name = "市盈率动"
                        item[name] = content
            yield item






