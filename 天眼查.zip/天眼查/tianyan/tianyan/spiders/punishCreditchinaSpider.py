import scrapy
import re
from scrapy import Selector

import config
from items import  PunishCreditchina

# 行政处罚【信用中国】
class punishCreditchinaSpider(scrapy.Spider):
    name = 'punishCreditchinaSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan.pipelines.PunishCreditchinaPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config.requset_header,
        'DOWMLOAD_DELY': 10,  # 睡眠时间
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        # 公司名称
        self.company_name = "".join(select.xpath(
            "//input[@id='header-company-search']/@value").extract())

        # 判断存在的公司信息
        div_ids = []
        div_titles = []
        infos = select.xpath(
            "//*[@id='web-content']/div[1]/div/div[3]/div[1]/div/div[1]/div/div//div[@class='item-container']//@onclick").extract()
        for info in infos:
            str = "".join(info)
            if "nav-main-past" not in str:
                div_ids.append("".join(re.compile(r"\'(\S+)\'").findall(str)))
        for div_id in div_ids:
            div_title = select.xpath(".//div[@id=$val]//text()[1]", val=div_id).extract_first()
            div_titles.append(div_title)

        if "行政处罚【信用中国】" in div_titles:
            punish_table = select.xpath(".//div[@id='_container_punishCreditchina']/table/tbody/tr")
            # 单页行政处罚
            item = PunishCreditchina()
            for punish_tr in punish_table:
                item['公司名称'] = self.company_name
                item['公司id'] = config.company_id
                item['模块id'] = "行政处罚【信用中国】"
                date = "".join(punish_tr.xpath("./td[2]/text()").extract())
                item['决定日期'] =date
                decision_number = "".join(punish_tr.xpath("./td[3]//text()").extract())
                item['决定书文号'] = decision_number
                defendant ="".join(decision_number)
                item['处罚名称'] = defendant
                announcement_type ="".join( punish_tr.xpath("./td[5]//text()").extract())
                item['处罚机关'] =announcement_type
                operation = "".join(punish_tr.xpath("./td[6]/script/text()").extract())
                item['操作'] =operation
                yield item