# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import  json
import  pymssql

class TianyanPipeline(object):
    def __init__(self):
        self.f=open("tianyan.json",'w',encoding='utf-8')
    def process_item(self, item,spider):
        text=json.dumps(dict(item),ensure_ascii=False)+",\n"
        self.f.write(text)
        return item
    def close_spider(self,spider):
        self.f.close()

# 股票行情
class VolatilityNumPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into t_volatilitynum(
              公司名称,公司id,股票名,股票id,今开,最高,涨停,昨收,最低,
              跌停,总市值,流通市值,成交量,成交额,
              市净率,市盈率动,振幅,换手,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['股票名'],item['股票id'],
            item['今开'],item['最高'],item['涨停'],item['昨收'],
            item['最低'],item['跌停'],item['总市值'],item['流通市值'] ,
            item['成交量'],item['成交额'],item['市净率'],
            item['市盈率动'],item['振幅'],item['换手'],item['模块id']))
        self.conn.commit()
        return item

# 企业简介
class IntroductionPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into introduction(
              公司名称,公司id,英文名称,曾用名,所属行业,主营业务,董事长,董秘,法人代表,
              总经理,注册资本,员工人数,控股股东,实际控制人,
              最终控制人,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['英文名称'],item['曾用名'],
            item['所属行业'],item['主营业务'],item['董事长'],item['董秘'],item['法人代表'],
            item['总经理'],item['注册资本'],item['员工人数'],item['控股股东'] ,
            item['实际控制人'],item['最终控制人'],item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 高管信息
class SerniorPeoplePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                      insert into seniorpeople(
                      公司名称,公司id,姓名,职务,持股数,年龄,学历,详情,
                      模块id)
                      values (%s,%s,%s,%s,%s,
                                  %s,%s,%s,%s)
                    """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['姓名'], item['职务'],
            item['持股数'], item['年龄'], item['学历'], item['详情'],
            item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 上市公告诉
class AnnouncementPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                      insert into listingnotice(
                      公司名称,公司id,日期,上市公告,公告地址,模块id)
                      values (%s,%s,%s,%s,%s,%s)
                    """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['日期'], item['上市公告'],
            item['公告地址'],item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 十大流通股东
class TopTenNumPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                          insert into toptennum(
                          公司名称,公司id,机构或基金,持有数量,占股本比例,实际增减持,股份类型,模块id)
                          values (%s,%s,%s,%s,%s,%s,%s,%s)
                        """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['机构或基金'], item['持有数量'],
             item['占股本比例'], item['实际增减持'], item['股份类型'], item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 十大流动股东
class TenTradableNumPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                          insert into tentradablenum(
                          公司名称,公司id,机构或基金,持有数量,占股本比例,实际增减持,股份类型,模块id)
                          values (%s,%s,%s,%s,%s,%s,%s,%s)
                        """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['机构或基金'], item['持有数量'],
             item['占股本比例'], item['实际增减持'], item['股份类型'], item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 股本变动
class EquityChangePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                                    insert into equitychange(
                                    公司名称,公司id,时间,变动原因,变动后A股总股本,
                                    变动后流通A股,变动后限售A股,模块id)
                                    values (%s,%s,%s,%s,%s,%s,%s,%s)
                                  """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['时间'], item['变动原因'],
            item['变动后A股总股本'], item['变动后流通A股'], item['变动后限售A股'],item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 分红情况
class BonusPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into bonus(
              公司名称,公司id,董事会日期,股东大会日期,实施日期,分红方案说明,A股股权登记日,A股股权除息日,A股派息日,
              方案进度,股利支付率,分红率,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['董事会日期'],item['股东大会日期'],
            item['实施日期'],item['分红方案说明'],item['A股股权登记日'],item['A股股权除息日'],item['A股派息日'],
            item['方案进度'],item['股利支付率'],item['分红率'],item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


# 分红情况
class BonusPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into bonus(
              公司名称,公司id,董事会日期,股东大会日期,实施日期,分红方案说明,A股股权登记日,A股股权除息日,A股派息日,
              方案进度,股利支付率,分红率,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['董事会日期'],item['股东大会日期'],
            item['实施日期'],item['分红方案说明'],item['A股股权登记日'],item['A股股权除息日'],item['A股派息日'],
            item['方案进度'],item['股利支付率'],item['分红率'],item['模块id']))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()




# 基本信息
class BaseinfoPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into baseinfo(
              公司名称,公司id,电话,邮箱,网址,地址,简介,公司状态,
              注册时间,注册资本,法定代表人,工商注册号,统一社会信用代码,
              纳税人识别号,营业期限,纳税人资质,实缴资本,参保人数,注册地址,
              经营范围,股权结构图,组织机构代码,公司类型,行业,核准日期,人员规模,
              登记机关,英文名称,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['电话'],item['邮箱'],
            item['网址'],item['地址'],item['简介'],item['公司状态'],
            item['注册时间'],item['注册资本'],item['法定代表人'],item['工商注册号'] ,
            item['统一社会信用代码'],item['纳税人识别号'],item['营业期限'],
            item['纳税人资质'],item['实缴资本'],item['参保人数'],item['注册地址'],
            item['经营范围'],item['股权结构图'],item['组织机构代码'],item['公司类型'],
            item['行业'],item['核准日期'],item['人员规模'],item['登记机关'],item['英文名称'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 天眼风险
class RiskPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into risk(公司名称,公司id,自身风险,周边风险,预警提醒,模块id)
              values (%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,( item['公司名称'],item['公司id'],item['自身风险'],item['周边风险'],item['预警提醒'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 主要人员
class StaffPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
            insert into staff(公司名称,公司id,主要人员,职位,模块id)
              values (%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['主要人员'],item['职位'],item['模块id']))
        self.conn.commit()
        return  item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 股东信息
class HolderPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()
    def process_item(self,item,spider):
        insert_sql="""
              insert into holder(公司名称,公司id,股东,出资比例,认缴出资,出资时间,模块id)
              values (%s,%s,%s,%s,%s,%s,%s)
              """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['股东'],item['出资比例'],item['认缴出资'],item['出资时间'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 对外投资
class InvestPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into invest(公司名称,公司id,被投资公司名称,被投资法定代表人,注册资本,投资占比,注册时间,状态,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['被投资公司名称'],
            item['被投资法定代表人'], item['注册资本'], item['投资占比'],
            item['注册时间'], item['状态'], item['模块id'],
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 变更记录
class ChangePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into change(公司名称,公司id,变更时间,变更项目,变更前,变更后,模块id)
              values (%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['变更时间'],item['变更项目'],item['变更前'],item['变更后'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 公司年报
class ReportPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into report(公司名称,公司id,年份,年报,模块id)
                values (%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['年份'],
                                         item['年报'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 理事会
class DirectorPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                             insert into director(公司名称,公司id,姓名,理事会职务,性别,年度会议次数,工作单位及职务,模块id)
                             values (%s,%s,%s,%s,%s,%s,%s,%s)
                       """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['姓名'], item['理事会职务'],
            item['性别'], item['年度会议次数'], item['工作单位及职务'],
            item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 监事会
class SupervisorPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                             insert into supervisor(公司名称,公司id,姓名,性别,年度会议次数,工作单位及职务,模块id)
                             values (%s,%s,%s,%s,%s,%s,%s)
                       """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['姓名'],
            item['性别'], item['年度会议次数'], item['工作单位及职务'],
            item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 分支机构
class BranchPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()
    def process_item(self,item,spider):
        insert_sql="""
              insert into branch(公司名称,公司id,企业名称,负责人,注册时间,状态,模块id)
              values (%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['企业名称'],
            item['负责人'], item['注册时间'], item['状态'],item['模块id']
          ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 法院公告
class AnnouncementcourtPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into announcementcourt(公司名称,公司id,开庭日期,案由,原告,被告,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
          """
        self.cursor.execute(insert_sql, (
            item['公司名称'],item['公司id'],item['开庭日期'],item['案由'],
            item['原告'],item['被告'],item['操作'],item['模块id'],
        ))
        self.conn.commit()
        return item
    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 法律诉讼
class LawsuitPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into lawsuit(公司名称,公司id,日期,裁判文书,案由,案件身份,案号,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'], item['公司id'],item['日期'],item['裁判文书'],
            item['案由'], item['案件身份'],item['案号'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 法院公告
class CourtPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                 insert into court(公司名称,公司id,公告时间,上诉方,被诉方,公告类型,法院,操作,模块id)
                 values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
           """
        self.cursor.execute(insert_sql, (
            item['公司名称'],item['公司id'],item['公告时间'],item['上诉方'],
            item['被诉方'],item['公告类型'],item['法院'],item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

#失信人信息
class DishonestPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into dishonest(公司名称,公司id,立案日期,案号,执行法院,履行状态,执行依据文号,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
          """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['立案日期'], item['案号'], item['执行法院'],
            item['履行状态'], item['执行依据文号'], item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 被执行人
class ExecutionPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into execution(公司名称,公司id,立案日期,执行标的,案号,执行法院,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['立案日期'],
                                        item['执行标的'],item['案号'],item['执行法院'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

#司法协助
class JudicialAidPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into judiciaaid(公司名称,公司id,被执行人,股权数额,执行通知文号,类型状态,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
          """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['被执行人'], item['股权数额'],
            item['执行通知文号'], item['类型状态'], item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 竞品信息
class JingpinPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into jingpin(公司名称,公司id,产品,地区,当前轮次,行业,业务,成立时间,估值,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['产品'],item['地区'],item['当前轮次'],
            item['行业'],item['业务'],item['成立时间'],item['估值'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

#经营异常
class  AbnormalPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into abnormal(公司名称,公司id,列入日期,列入原因,决定机关,移除日期,移除原因,移除机关,模块id)
              values 
              (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['列入日期'],item['列入原因'],item['决定机关'],
            item['移除日期'],item['移除原因'],item['移除机关'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


# 行政处罚 信用中国
class PunishCreditchinaPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into punishcreditchinaspider(公司名称,公司id,决定日期,决定书文号,处罚名称,处罚机关,操作,模块id)
              values 
              (%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['决定日期'],item['决定书文号'],item['处罚名称'],
            item['处罚机关'],item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 严重违法
class IllegaPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into illegal(公司名称,公司id,列入日期,列入原因,列入决定机关,移出日期,移出原因,移出决定机关,模块id)
                values 
                (%s,%s,%s,%s,%s,%s,%s,%s,%s)
          """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['列入日期'], item['列入原因'], item['列入决定机关'],
            item['移出日期'], item['移出原因'], item['移出决定机关'], item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 融资历史
class FinancingPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into financing(公司名称,公司id,时间,轮次,估值,金额,比例,投资方,新闻来源,模块id)
              values 
              (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['时间'],item['轮次'],item['估值'],
            item['金额'],item['比例'],item['投资方'],item['新闻来源'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


# 团队核心
class TeamMemberPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into teammember(公司名称,公司id,姓名,任职,任职经历,模块id)
              values 
              (%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['姓名'],item['任职'],item['任职经历'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 企业业务
class FirmProductPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into firmProduct(公司名称,公司id,服务名称,服务功能,服务类别,模块id)
              values (%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['服务名称'],item['服务功能'],item['服务类别'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 项目信息
class ProjectPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                     insert into project(公司名称,公司id,项目名称,年度收入万元,年度支出万元,关注领域,覆盖地域,详情,模块id)
                     values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
               """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['项目名称'], item['年度收入万元'],
            item['年度支出万元'], item['关注领域'], item['覆盖地域'],
            item['详情'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()



# 招聘
class RecruitPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into recruit(公司名称,公司id,发布时间,招聘职位,薪资,工作经验,招聘人数,所在城市,操作,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['发布时间'],
            item['招聘职位'],item['薪资'],item['工作经验'],
            item['招聘人数'],item['所在城市'],item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 行政许可【工商局】
class LicensingPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into licensing(公司名称,公司id,许可书文编号,许可文件名称,有效期自,有效期至,许可机关,许可内容,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['许可书文编号'],
                                        item['许可文件名称'],item['有效期自'],item['有效期至'],
                                        item['许可机关'],item['许可内容'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 行政许可【信用中国】
class LiceningXyzgPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into licensingxyzg(公司名称,公司id,行政许可文书号,许可决定机关,许可决定日期,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['行政许可文书号'],
                                        item['许可决定机关'],item['许可决定日期'],item['操作'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

#抽查检查
class CheckPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into check(公司名称,公司id,日期,类型,结果,检查实施机关,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['日期'],
                                         item['类型'], item['结果'], item['检查实施机关'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 股权出质
class EquityPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()
    def process_item(self, item, spider):
        insert_sql = """
                   insert into equity(公司名称,公司id,公告时间,登记编号,出质人,质权人,状态,操作,模块id)
                   values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
               """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['公告时间'],
                                         item['登记编号'], item['出质人'], item['质权人'],
                                         item['状态'], item['操作'], item['模块id']
                                         ))
        self.conn.commit()
        return item
    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 动产抵押
class MortgagePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()
    def process_item(self, item, spider):
        insert_sql = """
                insert into mortgage(公司名称,公司id,登记日期,登记号,被担保债权类型,被担保债权数额,登记机关,状态,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['登记日期'],
                                         item['登记号'], item['被担保债权类型'], item['被担保债权数额'], item['登记机关'],
                                         item['状态'],item['操作'],item['模块id']
                                         ))
        self.conn.commit()
        return item
    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 欠税公告
class TownTaxPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into towntax(公司名称,公司id,发布日期,纳税人识别号,欠税税种,当前发生的欠税额,欠税余额,税务机关,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['发布日期'],
                                         item['纳税人识别号'], item['欠税税种'], item['当前发生的欠税额'], item['欠税余额'],
                                         item['税务机关'],item['操作'],item['模块id']
                                         ))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 司法拍卖
class JudicialSalePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into judicialsale(公司名称,公司id,拍卖公告,拍卖链接,公告日期,执行法院,拍卖标的,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['拍卖公告'],
                                         item['拍卖链接'], item['公告日期'], item['执行法院'], item['拍卖标的'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 清算信息
class ClearingCountPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into clearingcount(公司名称,公司id,清算组负责人,清算组成员,模块id)
                values (%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['清算组负责人'],
                                         item['清算组成员'], item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


#公示催告
class PublicNoticePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into publicnotice(公司名称,公司id,票据号,票据类型,票面金额,公告日期,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['票据号'],
                                         item['票据类型'], item['票面金额'], item['公告日期'], item['操作'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 年检结果
class FinancePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into finance(公司名称,公司id,净资产,年度总收入,捐赠收入,投资收入,服务收入,
                        政府补助收入,其他收入,年度总支出,用于公益事业的支出,
                        工作人员工资福利支出,行政办公支出,其他支出,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (
            item['公司名称'], item['公司id'], item['净资产'],item['年度总收入'],item['捐赠收入'],
            item['投资收入'],item['服务收入'],item['政府补助收入'],item['其他收入'],
            item['年度总支出'],item['用于公益事业的支出'],item['工作人员工资福利支出'],
            item['行政办公支出'],item['其他支出'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 年检结果
class AnnualCheckPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into annualcheck(公司名称,公司id,年度,年检结果,模块id)
                values (%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['年度'],item['年检结果'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()



# 税收业务
class TaxCreditCountPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into taxcredit(公司名称,公司id,年份,纳税评级,类型,纳税人识别号,评价单位,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['年份'],
                                        item['纳税评级'],item['类型'],item['纳税人识别号'],item['评价单位'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 资质证书
class CretificatePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into certificationitem(公司名称,公司id,证书类型,证书编号,发证日期,截止日期,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['证书类型'],
            item['证书编号'],item['发证日期'],item['截止日期'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 招投标
class BidPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into bid(公司名称,公司id,发布时间,标题,采购人,模块id)
                values (%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['发布时间'],
            item['标题'],item['采购人'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 产品信息
class ProductInfoPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into productinfo(公司名称,公司id,产品名称,产品简称,产品分类,领域,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['产品名称'],
            item['产品简称'],item['产品分类'],item['领域'],item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 微信工作公众号
class WeChatPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into wechat(公司名称,公司id,微信公众号名,微信号,功能介绍,详情,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['微信公众号名'],
                                        item['微信号'],item['功能介绍'],item['详情'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

#进出口信息
class ImportAndExportPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into importandexport(公司名称,公司id,注册海关,海关编码,经营类别,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['注册海关'],
                                        item['海关编码'],item['经营类别'],item['操作'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 债务信息
class BondPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into bond(公司名称,公司id,发行日期,债券名称,债券代码,债券类型,最新评级,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['发行日期'],item['债券名称'],item['债券代码'],
            item['债券类型'],item['最新评级'],item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


# 购地信息
class PurchaslandPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into purchasland(公司名称,公司id,土地坐落,土地用途,总面积公顷,行政区,供应方式,签订日期,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['土地坐落'],item['土地用途'],item['总面积公顷'],
            item['行政区'],item['供应方式'],item['签订日期'],item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 电信许可
class TelePermissionPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into telepermission(公司名称,公司id,许可证号,业务范围,是否有效,操作,模块id)
              values (%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['许可证号'],item['业务范围'],item['是否有效'],item['操作'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 企业业务
class FirmProductPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into firmProduct(公司名称,公司id,服务名称,服务功能,服务类别,模块id)
              values (%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['服务名称'],item['服务功能'],item['服务类别'],item['模块id']
        ))
        self.conn.commit()
        return item
    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


# 投资事件
class InvestEventPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql="""
              insert into investevent(公司名称,公司id,时间,轮次,金额,投资方,产品,地区,行业,业务,模块id)
              values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """
        self.cursor.execute(insert_sql,(
            item['公司名称'],item['公司id'],item['时间'],
            item['轮次'],item['金额'], item['投资方'],item['产品'],
            item['地区'],item['行业'], item['业务'], item['模块id']
        ))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


#商标信息
class TmInfoPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into tminfo(公司名称,公司id,申请日期,商标,商标名称,注册号,类别,流程状态,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['申请日期'],
                                        item['商标'],item['商标名称'],item['注册号'],item['类别'],
                                        item['流程状态'],item['操作'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 专利信息
class PatentPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into patent(公司名称,公司id,申请公布日,专利名称,申请号,申请公布号,专利类型,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['申请公布日'],
                                        item['专利名称'],item['申请号'],item['申请公布号'],
                                        item['专利类型'],item['操作'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 软件著作权
class CopyrightPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into softwarecopyright(公司名称,公司id,批准日期,软件全称,软件简称,登记号,分类号,版本号,操作,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['批准日期'],
                                         item['软件全称'], item['软件简称'], item['登记号'],
                                         item['分类号'],item['版本号'],item['操作'], item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 作品著作权
class WorksCopyrightPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor=self.conn.cursor()
    def process_item(self,item,spider):
        insert_sql = """
                    insert into workscopyright(公司名称,公司id,作品名称,登记号,类别,创作完成日期,登记日期,首次发布日期,模块id)
                    values (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                """
        self.cursor.execute(insert_sql, (
            item['公司名称'],  item['公司id'], item['登记号'], item['类别'],
            item['创作完成日期'], item['创作完成日期'], item['登记日期'],
            item['首次发布日期'],  item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()


# 网站备案
class IcpPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into icp(公司名称,公司id,审核时间,网站名称,网站首页,域名,备案号,状态,单位性质,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['审核时间'],
                                         item['网站名称'], item['网站首页'], item['域名'],
                                         item['备案号'],item['状态'],item['单位性质'], item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 软件著作权
class ShareStructurePipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into sharestructure(公司名称,公司id,时间,总股本,A股总股本,流通A股,限售A股,H股总股本,流通H股,限售H股,变动原因,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['时间'],
                                         item['总股本'], item['A股总股本'], item['流通A股'],
                                         item['限售A股'],item['H股总股本'],item['流通H股'],item['限售H股'],item['变动原因'],item['模块id']
                                         ))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()