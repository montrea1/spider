# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy

# 股票行情
class VolatilityNumItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # volatilityNum
    股票名= scrapy.Field()
    股票id= scrapy.Field()
    今开= scrapy.Field()
    最高= scrapy.Field()
    涨停= scrapy.Field()
    昨收= scrapy.Field()
    最低= scrapy.Field()
    跌停= scrapy.Field()
    总市值= scrapy.Field()
    流通市值= scrapy.Field()
    成交量= scrapy.Field()
    成交额= scrapy.Field()
    市净率= scrapy.Field()
    市盈率动= scrapy.Field()
    振幅= scrapy.Field()
    换手= scrapy.Field()

# 企业简介
class IntroductionItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # intoduction
    英文名称= scrapy.Field()
    曾用名= scrapy.Field()
    所属行业= scrapy.Field()
    主营业务= scrapy.Field()
    董事长= scrapy.Field()
    董秘= scrapy.Field()
    法人代表= scrapy.Field()
    总经理 = scrapy.Field()
    注册资本= scrapy.Field()
    员工人数= scrapy.Field()
    控股股东= scrapy.Field()
    实际控制人= scrapy.Field()
    最终控制人= scrapy.Field()

# 高管信息
class SeniorPeopleItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # seniorPeople
    姓名 = scrapy.Field()
    职务 = scrapy.Field()
    持股数 = scrapy.Field()
    年龄 = scrapy.Field()
    学历 = scrapy.Field()
    详情 = scrapy.Field()

# 上市公告
class ListingNoticeItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # ListingNotice
    日期= scrapy.Field()
    上市公告= scrapy.Field()
    公告地址= scrapy.Field()


# 十大股东
class TopTemNumItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # TopTemNumItem
    机构或基金= scrapy.Field()
    持有数量= scrapy.Field()
    持股变化股= scrapy.Field()
    占股本比例= scrapy.Field()
    实际增减持= scrapy.Field()
    股份类型= scrapy.Field()

# 十大流通股东
class TenTradableNumItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # TenTradableNum
    机构或基金 = scrapy.Field()
    持有数量 = scrapy.Field()
    持股变化股 = scrapy.Field()
    占股本比例 = scrapy.Field()
    实际增减持 = scrapy.Field()
    股份类型 = scrapy.Field()

class ShareStructureItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # ShareStructure
    时间= scrapy.Field()
    总股本= scrapy.Field()
    A股总股本= scrapy.Field()
    流通A股= scrapy.Field()
    限售A股= scrapy.Field()
    H股总股本= scrapy.Field()
    流通H股= scrapy.Field()
    限售H股= scrapy.Field()
    变动原因= scrapy.Field()


# 股本变化
class EquityChangeItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # equityChange
    时间= scrapy.Field()
    变动原因= scrapy.Field()
    变动后A股总股本= scrapy.Field()
    变动后流通A股= scrapy.Field()
    变动后限售A股= scrapy.Field()

# 分红情况
class BonusItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # bonus
    董事会日期 = scrapy.Field()
    股东大会日期 = scrapy.Field()
    实施日期 = scrapy.Field()
    分红方案说明 = scrapy.Field()
    A股股权登记日 = scrapy.Field()
    A股股权除息日 = scrapy.Field()
    A股派息日 = scrapy.Field()
    方案进度 = scrapy.Field()
    股利支付率 = scrapy.Field()
    分红率 = scrapy.Field()


#公司基本信息
class BaseInfoItem(scrapy.Item):
    p=scrapy.Field()
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # baseinfo
    电话=scrapy.Field()
    邮箱=scrapy.Field()
    网址=scrapy.Field()
    地址=scrapy.Field()
    简介=scrapy.Field()

    公司状态=scrapy.Field()
    注册时间=scrapy.Field()
    注册资本=scrapy.Field()
    法定代表人=scrapy.Field()

    工商注册号=scrapy.Field()
    统一社会信用代码=scrapy.Field()
    纳税人识别号=scrapy.Field()
    营业期限=scrapy.Field()
    纳税人资质=scrapy.Field()
    实缴资本=scrapy.Field()
    参保人数=scrapy.Field()
    注册地址=scrapy.Field()
    经营范围=scrapy.Field()
    股权结构图=scrapy.Field()
    组织机构代码=scrapy.Field()
    公司类型=scrapy.Field()
    行业=scrapy.Field()
    核准日期=scrapy.Field()
    人员规模=scrapy.Field()
    登记机关=scrapy.Field()
    英文名称=scrapy.Field()


# 主要成员
class MainNumberItem(scrapy.Item):

    # main number
    主要人员=scrapy.Field()
    职位=scrapy.Field()

    # holder
    股东=scrapy.Field()
    出资比例=scrapy.Field()
    认缴出资=scrapy.Field()
    出资时间=scrapy.Field()

    # risk
    自身风险=scrapy.Field()
    周边风险=scrapy.Field()
    预警提醒=scrapy.Field()

    # inverst
    被投资公司名称=scrapy.Field()
    被投资法定代表人=scrapy.Field()
    注册资本=scrapy.Field()
    投资占比=scrapy.Field()
    注册时间=scrapy.Field()
    状态=scrapy.Field()

    # humanholding
    最终受益人名称 = scrapy.Field()
    持股比例 = scrapy.Field()
    股权链 = scrapy.Field()

    # change
    变更时间= scrapy.Field()
    变更项目= scrapy.Field()
    变更前= scrapy.Field()
    变更后= scrapy.Field()

    # branch
    企业名称= scrapy.Field()
    负责人= scrapy.Field()
    注册时间= scrapy.Field()
    状态= scrapy.Field()

    # announcement court
    开庭日期= scrapy.Field()
    案由= scrapy.Field()
    原告= scrapy.Field()
    被告= scrapy.Field()
    操作= scrapy.Field()

    # lawsuit
    日期= scrapy.Field()
    裁判文书= scrapy.Field()
    案由= scrapy.Field()
    案件身份= scrapy.Field()
    案号= scrapy.Field()

    # court
    公告时间= scrapy.Field()
    上诉方= scrapy.Field()
    被诉方= scrapy.Field()
    公告类型= scrapy.Field()
    法院= scrapy.Field()
    操作= scrapy.Field()

    #punishCreditchina
    决定日期= scrapy.Field()
    决定书文号= scrapy.Field()
    处罚名称= scrapy.Field()
    处罚机关= scrapy.Field()
    操作= scrapy.Field()

    #teamer
    姓名= scrapy.Field()
    职位= scrapy.Field()
    任职经历= scrapy.Field()

    # service
    服务名称= scrapy.Field()
    服务功能= scrapy.Field()
    服务类别= scrapy.Field()

    # jingpin
    产品= scrapy.Field()
    地区= scrapy.Field()
    当前轮次= scrapy.Field()
    行业= scrapy.Field()
    业务= scrapy.Field()
    成立时间= scrapy.Field()
    估值= scrapy.Field()

    # recruit
    发布时间= scrapy.Field()
    招聘职位= scrapy.Field()
    薪资= scrapy.Field()
    工作经验= scrapy.Field()
    招聘人数= scrapy.Field()
    所在城市= scrapy.Field()
    操作= scrapy.Field()

    # licensing
    许可书文编号= scrapy.Field()
    许可文件名称= scrapy.Field()
    有效期自= scrapy.Field()
    有效期至= scrapy.Field()
    许可机关= scrapy.Field()
    许可内容= scrapy.Field()

    # cerficate
    证书类型= scrapy.Field()
    证书编号= scrapy.Field()
    发证日期= scrapy.Field()
    截止日期= scrapy.Field()

    # taxcredit
    年份= scrapy.Field()
    纳税评级= scrapy.Field()
    类型= scrapy.Field()
    纳税人识别号= scrapy.Field()
    评价单位= scrapy.Field()

    # bid
    发布时间= scrapy.Field()
    标题= scrapy.Field()
    采购人= scrapy.Field()

    # product
    产品名称= scrapy.Field()
    产品简称= scrapy.Field()
    产品分类= scrapy.Field()
    领域= scrapy.Field()
    操作= scrapy.Field()

    # wechat
    微信公众号名= scrapy.Field()
    微信号= scrapy.Field()
    # 二维码= scrapy.Field()
    功能介绍= scrapy.Field()
    详情= scrapy.Field()

    # Customs
    注册海关= scrapy.Field()
    海关编码= scrapy.Field()
    经营类别= scrapy.Field()
    操作 = scrapy.Field()

    # purchaseland
    土地坐落= scrapy.Field()
    土地详情= scrapy.Field()
    土地用途= scrapy.Field()
    总面积公顷= scrapy.Field()
    行政区= scrapy.Field()
    供应方式= scrapy.Field()
    签订日期= scrapy.Field()

    # tmInfo
    申请日期= scrapy.Field()
    商标= scrapy.Field()
    商标名称= scrapy.Field()
    注册号= scrapy.Field()
    类别= scrapy.Field()
    流程状态= scrapy.Field()
    操作= scrapy.Field()

    # patent
    申请公布日= scrapy.Field()
    专利名称= scrapy.Field()
    申请号= scrapy.Field()
    申请公布号= scrapy.Field()
    专利类型= scrapy.Field()
    操作= scrapy.Field()

    # softwareCopyright
    批准日期= scrapy.Field()
    软件全称= scrapy.Field()
    软件简称= scrapy.Field()
    登记号= scrapy.Field()
    分类号= scrapy.Field()
    版本号= scrapy.Field()
    操作= scrapy.Field()

    # worksCopyright
    作品名称= scrapy.Field()
    登记号= scrapy.Field()
    类别= scrapy.Field()
    创作完成日期= scrapy.Field()
    登记日期= scrapy.Field()
    首次发布日期= scrapy.Field()

    # websitRecord
    审核时间= scrapy.Field()
    网站名称= scrapy.Field()
    网站首页= scrapy.Field()
    域名= scrapy.Field()
    备案号= scrapy.Field()
    状态= scrapy.Field()
    单位性质= scrapy.Field()

# 天眼风险
class RiskItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    # risk
    自身风险=scrapy.Field()
    周边风险=scrapy.Field()
    预警提醒=scrapy.Field()
    模块id = scrapy.Field()

# 主要人员
class StaffItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id=scrapy.Field()
    # staff
    主要人员 = scrapy.Field()
    职位 = scrapy.Field()
    模块id=scrapy.Field()

# 股东
class HolderItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id=scrapy.Field()
    # holder
    股东 = scrapy.Field()
    出资比例 = scrapy.Field()
    认缴出资 = scrapy.Field()
    出资时间 = scrapy.Field()

#对外投资
class InvestItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id=scrapy.Field()
    # inverst
    被投资公司名称=scrapy.Field()
    被投资法定代表人=scrapy.Field()
    注册资本=scrapy.Field()
    投资占比=scrapy.Field()
    注册时间=scrapy.Field()
    状态=scrapy.Field()

# 最终受益人

# 变更记录
class ChangeItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id=scrapy.Field()
    # change
    变更时间 = scrapy.Field()
    变更项目 = scrapy.Field()
    变更前 = scrapy.Field()
    变更后 = scrapy.Field()

# 公司年报
class ReportItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # report
    年份 = scrapy.Field()
    年报 = scrapy.Field()

# 分支机构
class BranchItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id=scrapy.Field()
    # branch
    企业名称 = scrapy.Field()
    负责人 = scrapy.Field()
    注册时间 = scrapy.Field()
    状态 = scrapy.Field()

# 理事会
class DirectorItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # director
    姓名= scrapy.Field()
    理事会职务= scrapy.Field()
    性别= scrapy.Field()
    年度会议次数= scrapy.Field()
    工作单位及职务= scrapy.Field()

# 监事会
class SupervisorItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # Supervisor
    姓名= scrapy.Field()
    性别= scrapy.Field()
    年度会议次数= scrapy.Field()
    工作单位及职务= scrapy.Field()


# 开庭公告
class CourtItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # court
    公告时间= scrapy.Field()
    上诉方= scrapy.Field()
    被诉方= scrapy.Field()
    公告类型= scrapy.Field()
    法院= scrapy.Field()
    操作= scrapy.Field()

# 法律诉讼
class LawsuitItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # lawsuit
    日期= scrapy.Field()
    裁判文书= scrapy.Field()
    案由= scrapy.Field()
    案件身份= scrapy.Field()
    案号= scrapy.Field()

#法庭公告
class AnnouncementItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id=scrapy.Field()
    # announcement court
    开庭日期= scrapy.Field()
    案由= scrapy.Field()
    原告= scrapy.Field()
    被告= scrapy.Field()
    操作= scrapy.Field()

# 失信人信息
class DishonestItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    #dishonest
    立案日期 = scrapy.Field()
    案号 = scrapy.Field()
    执行法院 = scrapy.Field()
    履行状态 = scrapy.Field()
    执行依据文号 = scrapy.Field()
    操作 = scrapy.Field()


# 被执行人
class ExecutionItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # execution
    立案日期= scrapy.Field()
    执行标的= scrapy.Field()
    案号= scrapy.Field()
    执行法院= scrapy.Field()

# 司法协助
class JudicialaAidItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # judiciala aid
    被执行人= scrapy.Field()
    股权数额= scrapy.Field()
    执行法院= scrapy.Field()
    执行通知文号= scrapy.Field()
    类型状态= scrapy.Field()
    操作= scrapy.Field()

# 经营异常
class AbnormalItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # abnormal
    列入日期= scrapy.Field()
    列入原因= scrapy.Field()
    决定机关= scrapy.Field()
    移除日期= scrapy.Field()
    移除原因= scrapy.Field()
    移除机关= scrapy.Field()

#行政处罚【信用中国】
class PunishCreditchina(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # punishCreditchina
    决定日期=scrapy.Field()
    决定书文号 = scrapy.Field()
    处罚名称 = scrapy.Field()
    处罚机关 = scrapy.Field()
    操作 = scrapy.Field()

# 严重违法
class IllegalItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # illega
    列入日期 = scrapy.Field()
    列入原因 = scrapy.Field()
    列入决定机关 = scrapy.Field()
    移出日期 = scrapy.Field()
    移出原因 = scrapy.Field()
    移出决定机关 = scrapy.Field()


#股权出质
class EquityItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # equity
    公告时间 = scrapy.Field()
    登记编号 = scrapy.Field()
    出质人 = scrapy.Field()
    质权人 = scrapy.Field()
    状态 = scrapy.Field()
    操作 = scrapy.Field()

# 动产抵押
class MortgageItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # mortgage
    登记日期 = scrapy.Field()
    登记号 = scrapy.Field()
    被担保债权类型 = scrapy.Field()
    被担保债权数额 = scrapy.Field()
    登记机关 = scrapy.Field()
    状态 = scrapy.Field()
    操作 = scrapy.Field()

# 欠税公告
class Towntaxitem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # towntax
    发布日期 = scrapy.Field()
    纳税人识别号 = scrapy.Field()
    欠税税种 = scrapy.Field()
    当前发生的欠税额 = scrapy.Field()
    欠税余额 = scrapy.Field()
    税务机关 = scrapy.Field()
    操作 = scrapy.Field()

#司法拍卖
class JudicialSaleItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # judicialSale
    拍卖公告= scrapy.Field()
    拍卖链接= scrapy.Field()
    公告日期= scrapy.Field()
    执行法院= scrapy.Field()
    拍卖标的= scrapy.Field()

class ClearingCountItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # clearingCount
    清算组负责人= scrapy.Field()
    清算组成员= scrapy.Field()

# 公示催告
class PublicNoticeItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # publicnoticeItem
    票据号 = scrapy.Field()
    票据类型 = scrapy.Field()
    票面金额 = scrapy.Field()
    发布机构 = scrapy.Field()
    公告日期 = scrapy.Field()
    操作 = scrapy.Field()

class AnnualCheckItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # annualCheck
    年度= scrapy.Field()
    年检结果= scrapy.Field()


# 财务信息
class FinanceItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # finance
    净资产= scrapy.Field()
    年度总收入= scrapy.Field()
    捐赠收入= scrapy.Field()
    投资收入= scrapy.Field()
    服务收入= scrapy.Field()
    政府补助收入= scrapy.Field()
    其他收入= scrapy.Field()
    年度总支出= scrapy.Field()
    用于公益事业的支出= scrapy.Field()
    工作人员工资福利支出= scrapy.Field()
    行政办公支出= scrapy.Field()
    其他支出= scrapy.Field()

# 融资历史
class Finacingitem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # financing
    时间= scrapy.Field()
    轮次= scrapy.Field()
    估值= scrapy.Field()
    金额= scrapy.Field()
    比例= scrapy.Field()
    投资方= scrapy.Field()
    新闻来源= scrapy.Field()


# 核心团队
class TeamMember(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # temMember
    姓名= scrapy.Field()
    任职= scrapy.Field()
    任职经历= scrapy.Field()

# 业务产品
class FirmProductItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # service
    服务名称= scrapy.Field()
    服务功能= scrapy.Field()
    服务类别= scrapy.Field()

# 投资事件
class InvestEventItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # investment event
    时间= scrapy.Field()
    轮次= scrapy.Field()
    金额= scrapy.Field()
    投资方= scrapy.Field()
    产品= scrapy.Field()
    地区= scrapy.Field()
    行业= scrapy.Field()
    业务= scrapy.Field()

# 竞品信息
class JingpinItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # jingpin
    产品 = scrapy.Field()
    地区 = scrapy.Field()
    当前轮次 = scrapy.Field()
    行业 = scrapy.Field()
    业务 = scrapy.Field()
    成立时间 = scrapy.Field()
    估值 = scrapy.Field()

# 项目信息
class ProjectItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # project
    项目名称 = scrapy.Field()
    年度收入万元 = scrapy.Field()
    年度支出万元 = scrapy.Field()
    关注领域 = scrapy.Field()
    覆盖地域 = scrapy.Field()
    详情 = scrapy.Field()



# 招聘
class RecruitItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # recruit
    发布时间= scrapy.Field()
    招聘职位= scrapy.Field()
    薪资= scrapy.Field()
    工作经验= scrapy.Field()
    招聘人数= scrapy.Field()
    所在城市= scrapy.Field()
    操作= scrapy.Field()

# 行政许可【工商局】
class LicensingItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # license
    许可书文编号= scrapy.Field()
    许可文件名称= scrapy.Field()
    有效期自= scrapy.Field()
    有效期至= scrapy.Field()
    许可机关= scrapy.Field()
    许可内容= scrapy.Field()

# 行政许可【信用中国】
class LicensingXyzgItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # license
    行政许可文书号= scrapy.Field()
    许可决定机关= scrapy.Field()
    许可决定日期= scrapy.Field()
    操作= scrapy.Field()

# 抽查检查
class CheckItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # check
    日期= scrapy.Field()
    类型= scrapy.Field()
    结果= scrapy.Field()
    检查实施机关= scrapy.Field()


# 税收评级
class TaxcreditItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # taxcredit
    年份 = scrapy.Field()
    纳税评级 = scrapy.Field()
    类型 = scrapy.Field()
    纳税人识别号 = scrapy.Field()
    评价单位 = scrapy.Field()

# 资质证书
class CertificateItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # cerficate
    证书类型= scrapy.Field()
    证书编号= scrapy.Field()
    发证日期= scrapy.Field()
    截止日期= scrapy.Field()

# 招投标
class BidItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # bid
    发布时间 = scrapy.Field()
    标题 = scrapy.Field()
    采购人 = scrapy.Field()

# 产品信息
class ProductInfoItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # productInfo
    产品名称= scrapy.Field()
    产品简称= scrapy.Field()
    产品分类= scrapy.Field()
    领域= scrapy.Field()
    操作= scrapy.Field()


# 微信公众号
class WechatItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # wechat
    微信公众号名= scrapy.Field()
    微信号= scrapy.Field()
    # 二维码= scrapy.Field()
    功能介绍= scrapy.Field()
    详情= scrapy.Field()

# 购地信息
class PurchaselandItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # purchaseland
    土地坐落 = scrapy.Field()
    土地用途 = scrapy.Field()
    总面积公顷 = scrapy.Field()
    行政区 = scrapy.Field()
    供应方式 = scrapy.Field()
    签订日期 = scrapy.Field()


# 进出口信息
class ImportAndExportItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # customs
    注册海关 = scrapy.Field()
    海关编码 = scrapy.Field()
    经营类别 = scrapy.Field()
    操作 = scrapy.Field()

# 债务信息
class BondItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # bond
    发行日期= scrapy.Field()
    债券名称= scrapy.Field()
    债券代码= scrapy.Field()
    债券类型= scrapy.Field()
    最新评级= scrapy.Field()
    操作= scrapy.Field()

# 电信许可
class TelePermission(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # permission
    许可证号 = scrapy.Field()
    业务范围 = scrapy.Field()
    是否有效 = scrapy.Field()
    操作 = scrapy.Field()

# 商标信息
class TmInfoItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # TMinfo
    申请日期= scrapy.Field()
    商标= scrapy.Field()
    商标名称= scrapy.Field()
    注册号= scrapy.Field()
    类别= scrapy.Field()
    流程状态= scrapy.Field()
    操作= scrapy.Field()


# 专利信息
class PatentItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # patent
    申请公布日= scrapy.Field()
    专利名称= scrapy.Field()
    申请号= scrapy.Field()
    申请公布号= scrapy.Field()
    专利类型= scrapy.Field()
    操作= scrapy.Field()

# 软件著作权
class CopyrightSoftwareItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # softwareCopyright
    批准日期 = scrapy.Field()
    软件全称 = scrapy.Field()
    软件简称 = scrapy.Field()
    登记号 = scrapy.Field()
    分类号 = scrapy.Field()
    版本号 = scrapy.Field()
    操作 = scrapy.Field()

# 作品著作权
class WorksCopyrightItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # worksCopyright
    作品名称= scrapy.Field()
    登记号= scrapy.Field()
    类别= scrapy.Field()
    创作完成日期= scrapy.Field()
    登记日期= scrapy.Field()
    首次发布日期= scrapy.Field()

# 网站备案
class IcpItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # websitRecord
    审核时间 = scrapy.Field()
    网站名称 = scrapy.Field()
    网站首页 = scrapy.Field()
    域名 = scrapy.Field()
    备案号 = scrapy.Field()
    状态 = scrapy.Field()
    单位性质 = scrapy.Field()