# 解析工具TruFont..exe
# 使用方法：
    #   安装工具
    #   参考网址： https://blog.csdn.net/scutjcfeng/article/details/79620072



# 对页面加密的字体进行解析
number_maps={
      '8' : '0',
      '9' : '1',
      '5' : '2',
      '4' : '3',
      '7' : '5',
      '0' : '6',
      '6' : '7',
      '3' : '8',
      '1' : '9' ,
      '足':'万',
      '孩':'民'

}

# 解析加密字体方法
# 遍历已加密字符串，通过map，获取对应值
# 将获取值加入新字符串
# 返回已解析字符串
def  convert(data):
    result=""
    for s in data:
        if s in number_maps:
            result+=number_maps[s]
        else:
            result+=s
    return  result

if __name__ == '__main__':
    data = "6823-84-69"
    print( convert(data=data))