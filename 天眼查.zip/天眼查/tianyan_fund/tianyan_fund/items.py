# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy



# 基金管理人
class FundItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    #fund= scrapy.Field()
    企业名称= scrapy.Field()
    法定代表人= scrapy.Field()
    注册资本= scrapy.Field()
    成立日期= scrapy.Field()

#机构成员
class MembersItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # member
    姓名 = scrapy.Field()
    职位 = scrapy.Field()
    简介 = scrapy.Field()

# 基金管理
class ManageFundItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # manageFund
    企业名= scrapy.Field()
    法定代表人= scrapy.Field()
    注册资本= scrapy.Field()
    成立日期= scrapy.Field()

# 对外投资基金
class ForeignFundItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # foreignfund
    企业名= scrapy.Field()
    法定代表人= scrapy.Field()
    注册资本= scrapy.Field()
    成立日期= scrapy.Field()
    投资方=scrapy.Field()

# 投资动态
class DynamicItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # dynamic
    产品名= scrapy.Field()
    融资轮次= scrapy.Field()
    投资时间= scrapy.Field()
    投资金额= scrapy.Field()
    内容= scrapy.Field()

# 投资动态
class IndustryItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # Industry
    企业名称= scrapy.Field()
    投资时间= scrapy.Field()
    被投资公司= scrapy.Field()
    投资比例= scrapy.Field()

# 投资事件
class Investment(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # Industry
    产品名 = scrapy.Field()
    融资信息= scrapy.Field()
    投资时间= scrapy.Field()
    投资金额 = scrapy.Field()
    产品介绍= scrapy.Field()

# 未公开投资事件
class UnInvestmentItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # Uninvestment
    企业名= scrapy.Field()
    法定代表人= scrapy.Field()
    注册资本= scrapy.Field()
    成立日期	= scrapy.Field()
    投资方= scrapy.Field()

class NewsTrendsItem(scrapy.Item):
    公司名称 = scrapy.Field()
    公司id = scrapy.Field()
    模块id = scrapy.Field()
    # NewsTrends
    投资机构= scrapy.Field()
    时间= scrapy.Field()
    来源= scrapy.Field()
    内容= scrapy.Field()
    内容地址= scrapy.Field()