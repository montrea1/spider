# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import  pymssql


class TianyanFundPipeline(object):
    def process_item(self, item, spider):
        return item

# 基金管理人
class FundPipeline():
    def __init__(self):
        server="9KF13M2CZPI24ZK"
        user="sa"
        password="123456"
        database="eyecheck_organize"
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor=self.conn.cursor()

    def process_item(self,item,spider):
        insert_sql = """
                insert into fund(公司名称,公司id,企业名称,法定代表人,注册资本,成立日期,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql,(item['公司名称'],item['公司id'],item['企业名称'],item['法定代表人'],
                                        item['注册资本'],item['成立日期'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self,spider):
        self.cursor.close()
        self.conn.close()

# 机构成员
class MembersPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into members(公司名称,公司id,姓名,职位,简介,模块id)
                values (%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['姓名'], item['职位'],
                                         item['简介'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 管理基金
class ManageFundPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into managefund(公司名称,公司id,企业名,法定代表人,注册资本,成立日期,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['企业名'], item['法定代表人'],
                                         item['注册资本'],item['成立日期'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 对外投资基金
class ForeignFundPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into foreignfund(公司名称,公司id,企业名,法定代表人,注册资本,成立日期,投资方,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['企业名'], item['法定代表人'],
                                         item['注册资本'],item['成立日期'],item['投资方'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 投资动态
class DynamicPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into dynamic(公司名称,公司id,产品名,融资轮次,投资时间,投资金额,内容,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['产品名'], item['融资轮次'],
                                         item['投资时间'],item['投资金额'],item['内容'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()


# 工商追踪
class IndustryPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into industry(公司名称,公司id,企业名称,投资时间,被投资公司,投资比例,模块id)
                values (%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['企业名称'], item['投资时间'],
                                         item['被投资公司'],item['投资比例'],item['模块id']))
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 公开投资事件
class  InvestmentPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into fund_investment(公司名称,公司id,产品名,融资信息,投资时间,投资金额,产品介绍,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['产品名'], item['融资信息'],
                                         item['投资时间'],item['投资金额'],item['产品介绍'],item['模块id']));
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 未公开投资事件
class  UninvestmentPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into uninvestment(公司名称,公司id,企业名,法定代表人,注册资本,成立日期,投资方,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['企业名'], item['法定代表人'],
                                         item['注册资本'],item['成立日期'],item['投资方'],item['模块id']));
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()

# 新闻动态
class NewsTrendsPipeline():
    def __init__(self):
        self.conn = pymssql.connect("9KF13M2CZPI24ZK", "sa", "123456", "eyecheck_organize")
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        insert_sql = """
                insert into newstrends(公司名称,公司id,投资机构,时间,来源,内容,内容地址,模块id)
                values (%s,%s,%s,%s,%s,%s,%s,%s)
            """
        self.cursor.execute(insert_sql, (item['公司名称'], item['公司id'], item['投资机构'], item['时间'],
                                         item['来源'],item['内容'],item['内容地址'],item['模块id']));
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()