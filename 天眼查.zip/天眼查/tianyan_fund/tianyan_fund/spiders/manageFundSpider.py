import scrapy
import re
from scrapy import Selector
import config_fund
from tianyan_fund.items import  ManageFundItem

# 管理基金
class ManageFundSpider(scrapy.Spider):
    name = 'ManageFundSpider'
    allowed_domains = ['tianyaEncha.com']
    start_urls =config_fund.start_url

    custom_settings = {
        'ITEM_PIPELINES': {
            'tianyan_fund.pipelines.ManageFundPipeline': 200
        },
        'DEFAULT_REQUEST_HEADERS': config_fund.requset_header,
        'REDIRECT_ENABLED': True,  # 允许重定向
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url=url, cookies=config_fund.Cookies)

    def parse(self, response):
        html_str = response.text
        select = Selector(text=html_str)
        # 公司名称
        self.company_name = "".join(select.xpath(
            "//*[@id='web-content']//div[@class='content']/div[@class='header']/div[@class='name']/text()").extract())

        # 判断模块是否存在
        if select.xpath(".//div[@id='_container_manageFund']") is not None:
            page_url = "https://www.tianyancha.com/pagination_organize/manageFund.xhtml?&id=%s"%(config_fund.company_id[-4:])
            yield scrapy.Request(url=page_url, cookies=config_fund.Cookies, callback=self.parse_content,
                                 dont_filter=True)
    # 解析爬取
    def parse_content(self, response):
        html_str = response.text
        select = Selector(text=html_str)

        item = ManageFundItem()
        table = select.xpath(".//table/tbody/tr")
        for tr in table:
            item['公司名称'] = self.company_name
            item['公司id'] = config_fund.company_id
            item['模块id'] = "管理基金"
            item['企业名'] =  "".join(tr.xpath("./td[2]/a//text()").extract())
            item['法定代表人'] = "".join(tr.xpath("./td[3]/a[@class='link-click']//text()").extract())
            item['注册资本'] = "".join(tr.xpath("./td[4]//text()").extract())
            item['成立日期']="".join(tr.xpath("./td[5]//text()").extract())
            yield item

        #爬取多页
        next_page = select.xpath("//div[@class='company_pager']/ul//li/a[@class='num -next']/@onclick")
        if len(next_page) != 0:
            num = "".join(next_page.re(r'\d'))
            page_url = "https://www.tianyancha.com/pagination_organize/manageFund.xhtml?pn=%s&id=%s" % (num, "".join(config_fund.company_id[-4:]))
            yield scrapy.Request(url=page_url, cookies=config_fund.Cookies, callback=self.parse_content,
                                 dont_filter=True)







