# -*- coding: utf-8 -*-
import os
# 必须先加载项目settings配置
# project需要改为你的工程名字（即settings.py所在的目录名字）
os.environ.setdefault('SCRAPY_SETTINGS_MODULE', 'tianyan_fund.settings')
import scrapy
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
process = CrawlerProcess(get_project_settings())

# process.crawl("FundSpider")
# process.crawl("MembersSpider")
# process.crawl("ManageFundSpider")
# process.crawl("ForeignFundSpider")
#process.crawl("DynamicSpider")
# process.crawl("IndustrySpider")
# process.crawl("InvestmentSpider")
# process.crawl("UninvestmentSpider")
process.crawl("NewsTrendsSpider")
process.start()

