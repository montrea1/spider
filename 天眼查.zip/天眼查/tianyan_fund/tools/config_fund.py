import random

# 公司id
company_id="b49032985"
start_url=['https://www.tianyancha.com/organize/' + company_id]

# cookies
Cookies = {
    'TYCID': '9a98edd0d37811e8a3b4156b73d5859e',
    'undefined': '9a98edd0d37811e8a3b4156b73d5859e',
    'ssuid': '8322746494',
    '_ga': 'GA1.2.1858014942.1539937562',
    'tyc-user-info': '%257B%2522myQuestionCount%2522%253A%25220%2522%252C%2522integrity%2522%253A%25220%2525%2522%252C%2522state%2522%253A%25220%2522%252C%2522vipManager%2522%253A%25220%2522%252C%2522onum%2522%253A%25220%2522%252C%2522monitorUnreadCount%2522%253A%252219%2522%252C%2522discussCommendCount%2522%253A%25221%2522%252C%2522token%2522%253A%2522eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxNTc2NzM5MTM0NSIsImlhdCI6MTU0MzA0MzMyOSwiZXhwIjoxNTU4NTk1MzI5fQ.C1cczxL6OEoE_mDCIHO-xbxg2P7CrSYOd6VkoyxmoPITsh0TNxtQJxkOzf_kBnVB4AGFXW4m9KHkBbaLGbog0w%2522%252C%2522redPoint%2522%253A%25220%2522%252C%2522pleaseAnswerCount%2522%253A%25221%2522%252C%2522vnum%2522%253A%25220%2522%252C%2522bizCardUnread%2522%253A%25220%2522%252C%2522mobile%2522%253A%252215767391345%2522%257D',
    'auth_token': 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIxNTc2NzM5MTM0NSIsImlhdCI6MTU0MzA0MzMyOSwiZXhwIjoxNTU4NTk1MzI5fQ.C1cczxL6OEoE_mDCIHO-xbxg2P7CrSYOd6VkoyxmoPITsh0TNxtQJxkOzf_kBnVB4AGFXW4m9KHkBbaLGbog0w',
    'RTYCID': '18a6ae69db854f2cbc5ee4c3fb5ab3b7',
    'CT_TYCID': 'bb3b8afa0e4242a6934b8230c31dfd31',
    'aliyungf_tc': 'AQAAACKc4Fcg3gIAg1zut9DvyDwZOUmR',
    'csrfToken': 'MI8MbjSN5tSshkAOp2a-lA-t',
    'Hm_lvt_e92c8d65d92d534b0fc290df538b4758': '1543932054,1543932187,1544058965,1544165796',
    '_gid': 'GA1.2.163589285.1544165799',
    'Hm_lpvt_e92c8d65d92d534b0fc290df538b4758': '1544165807',
    'cloud_token': '8a2467570fc04b2f916487d7be177c39',
    'bannerFlag': 'true',
    'token': '451fdc720ec5488682508c2364ba49ab',
    '_utm': '033efd6748fa47449e42cce60a203523'
}

# 请求头
requset_header={
        "Accept":"*/*",
        "Accept-Encoding":"gzip, deflate, br",
        "Accept-Language":"zh-CN,zh;q=0.9",
        "Connection":"keep-alive",
        "Cookie":Cookies,
        "Host":"www.tianyancha.com",
        "Referer":"https://www.tianyancha.com/company/333429504",
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36",
        "X-Requested-With":"XMLHttpRequest"
    }


# 多个代理
user_agents= [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/537.75.14",
    "Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Win64; x64; Trident/6.0)"
    ]

header={
    "Accept":" */*",
    "Accept-Encoding":" gzip, deflate, br",
    "Accept-Language":" zh-CN,zh;q=0.9",
    "Connection":" keep-alive",
    "Cookie":Cookies,
    "Host":" www.tianyancha.com",
    "Referer":" https://www.tianyancha.com/company/150041670",
    "User-Agent":random.choice(user_agents),
    "X-Requested-With":" XMLHttpRequest"
}


