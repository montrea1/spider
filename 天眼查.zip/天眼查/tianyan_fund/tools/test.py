import config

print(type(config.company_id[-4:]))
